package PaooGame;

import java.util.InputMismatchException;

public class MyInputMissMatchException extends InputMismatchException {
    public String location;
    public MyInputMissMatchException(String where) {
        super();
        location=where;
    }
    @Override
    public String getMessage()
    {
        return "InputMismatchException at :"+location;
    }
}
