package PaooGame;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/** listens to user input on awt components */
public class ActionListenerClass implements ActionListener {

    boolean isClicked;

    public ActionListenerClass(){
        super();
        isClicked=false;
    }
    @Override
    //if an actionevent in performed, then isClicked=true
    public void actionPerformed(ActionEvent e) {
        isClicked=true;
    }
}
