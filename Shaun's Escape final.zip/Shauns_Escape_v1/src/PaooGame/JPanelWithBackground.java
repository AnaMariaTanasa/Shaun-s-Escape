package PaooGame;

import PaooGame.Graphics.ImageLoader;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;

public class JPanelWithBackground extends JPanel {
    private BufferedImage background;

    public JPanelWithBackground(String imagePath) {
        super();
        try {
            background = ImageLoader.LoadImage(imagePath);
        }
        catch(NullPointerException e) {
            System.out.println("Image not found in JPanelWithBackground");
            e.printStackTrace();
        }

    }
    @Override
    public void paintComponent(Graphics g) {

        super.paintComponent(g);
        // Draw the background image
            g.drawImage(background, 0, 0, Main.width, Main.height, this);
    }
}
