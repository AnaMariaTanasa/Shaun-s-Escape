package PaooGame.Tiles;

public enum collisionTrue
{
    YES,NO
}
