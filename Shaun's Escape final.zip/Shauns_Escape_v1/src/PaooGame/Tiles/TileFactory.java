package PaooGame.Tiles;
import java.util.HashMap;
import java.util.Map;
public class TileFactory {
    private Map<Integer,Tile> tiles=new HashMap<>();
    public Tile getTile(int idd){
        if(!tiles.containsKey(idd)){
            if(idd!=-1 && idd!=5)//non-solid tiles
            {
                tiles.put(idd,new SolidTile(idd));
            }
            else
            {
                tiles.put(idd,new NSolidTile(idd));
            }
        }
        return tiles.get(idd);
    }
}
