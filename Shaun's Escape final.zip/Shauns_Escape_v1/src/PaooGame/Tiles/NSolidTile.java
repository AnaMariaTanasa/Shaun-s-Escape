package PaooGame.Tiles;

import java.awt.*;
import java.awt.image.BufferedImage;

import static PaooGame.Graphics.Assets.textures;

public class NSolidTile implements Tile{
    final collisionTrue collision=collisionTrue.NO;
    private final int id;
    public NSolidTile(int idd)
    {
        id=idd;

    }

    @Override
    public collisionTrue IsSolid() {
        return collision;
    }

    @Override
    public int GetId() {
        return id;
    }

    @Override
    public void Draw(Graphics g, int x, int y) {
        g.drawImage(textures[id], x, y, null);
    }
    public void Update()
    {

    }
}
