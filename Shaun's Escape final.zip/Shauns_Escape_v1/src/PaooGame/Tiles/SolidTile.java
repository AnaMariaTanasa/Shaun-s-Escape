package PaooGame.Tiles;

import java.awt.*;

import static PaooGame.Graphics.Assets.textures;

public class SolidTile implements Tile{
    final collisionTrue collision=collisionTrue.YES;
    private final int id;

    public SolidTile(int idd)
    {
        id=idd;

    }

    @Override
    public collisionTrue IsSolid() {
        return collision;
    }

    @Override
    public int GetId() {
        return id;
    }

    @Override
    public void Draw(Graphics g, int x, int y) {
        g.drawImage(textures[id], x, y,ACTUAL_TILE_WIDTH,ACTUAL_TILE_HEIGHT, null);
    }
    public void Update()
    {

    }
}
