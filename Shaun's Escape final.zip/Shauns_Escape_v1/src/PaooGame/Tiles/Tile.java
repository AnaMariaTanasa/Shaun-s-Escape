package PaooGame.Tiles;

import java.awt.*;

/*! \class public class Tile
    \brief Retine toate dalele intr-un vector si ofera posibilitatea regasirii dupa un id.
 */
public interface  Tile
{

    //public static final int NO_TILES   = 32;
    ///public static Tile[] tiles          = new Tile[NO_TILES];       /*!< Vector de referinte de tipuri de dale.*/

    public static final int[] TILE_COLLISION={0,1,2,3,4,6,7,8,9,10,14,15,16,17,18,19,20,21,22};
    public static int scale=1;
    public static final int TILE_HEIGHT = 32;                       /*!< Inaltimea unei dale.*/
    public static final int ACTUAL_TILE_HEIGHT = TILE_HEIGHT*scale;                       /*!< Inaltimea unei dale.*/
    public static final int TILE_WIDTH  = 32;/*!< Latimea unei dale.*/
    public static final int ACTUAL_TILE_WIDTH  = TILE_WIDTH*scale;
    public void Update();

    public void Draw(Graphics g, int x, int y);
    public collisionTrue IsSolid();

    public int GetId();

}
