package PaooGame;

import PaooGame.Entity.AbstractMonster;
import PaooGame.Entity.Entity;
import PaooGame.Entity.PlayerLevel1;
import PaooGame.Graphics.Map;
import PaooGame.Objects.AbstractObject;

import static PaooGame.Tiles.Tile.*;

/** class used for checking collisions */
public class CollisionChecker {

    public CollisionChecker() {

    }

    public static void checkTile(Entity entity, Map map)  {
        int entityLeftWorldX = entity.worldX + entity.solidArea.x;
        int entityRightWorldX = entity.worldX + entity.solidArea.x + entity.solidArea.width;
        int entityTopWorldY = entity.worldY + entity.solidArea.y;
        int entityBottomWorldY = entity.worldY + entity.solidArea.y + entity.solidArea.height;

        int entityLeftCol = entityLeftWorldX / ACTUAL_TILE_WIDTH;
        int entityRightCol = entityRightWorldX / ACTUAL_TILE_WIDTH;
        int entityTopRow = entityTopWorldY / ACTUAL_TILE_HEIGHT;
        int entityBottomRow = entityBottomWorldY / ACTUAL_TILE_HEIGHT;


        int j;
        int i;
        int aux;
        boolean ok = false;
        if (entity.jump == true)//verificam TOPY
        {
            j = (entityTopWorldY - entity.speed) / ACTUAL_TILE_HEIGHT;
            for (i = entityLeftCol; i <= entityRightCol; i++) {
                try {
                    aux = map.getTileID(j, i);
                    for (int k : TILE_COLLISION)
                        if (k == aux) {
                            ok = true;
                            break;
                        }
                }
                catch(MatrixIndexOutOfBounds e) {
                    System.out.println(e.getMessage());
                    e.printStackTrace();
                }
            }
        }


        if (entity.direction.equals("left")) //verificam LeftCol
        {
            j = (entityLeftWorldX - entity.speed) / ACTUAL_TILE_WIDTH;
            for (i = entityTopRow; i <= entityBottomRow; i++) {
                try {
                    aux = map.getTileID(i, j);
                    for (int k : TILE_COLLISION)
                        if (k == aux) {
                            ok = true;
                            break;
                        }
                }
                catch(MatrixIndexOutOfBounds e) {
                    System.out.println(e.getMessage());
                    e.printStackTrace();
                }
            }
        }

        if (entity.direction.equals("right") || entity.attack == true) //verificam RightCol
        {

            j = (entityRightWorldX + entity.speed) / ACTUAL_TILE_WIDTH;
            for (i = entityTopRow; i <= entityBottomRow; i++) {
                try {
                    aux = map.getTileID(i, j);

                    for (int k : TILE_COLLISION)
                        if (k == aux) {
                            ok = true;
                            break;
                        }
                }
                catch(MatrixIndexOutOfBounds e) {
                    System.out.println(e.getMessage());
                    e.printStackTrace();
                }
            }

        }

        entity.collisionOn = ok;
    }

    public static boolean checkTileUp(Entity entity, Map map) {
        int entityLeftWorldX = entity.worldX + entity.solidArea.x;
        int entityRightWorldX = entity.worldX + entity.solidArea.x + entity.solidArea.width;
        int entityTopWorldY = entity.worldY + entity.solidArea.y;
        int entityLeftCol = entityLeftWorldX / ACTUAL_TILE_WIDTH;
        int entityRightCol = entityRightWorldX / ACTUAL_TILE_WIDTH;
        int j;
        int i;
        int aux;
        boolean ok = false;
        j = (entityTopWorldY - entity.speed) / ACTUAL_TILE_HEIGHT;
        for (i = entityLeftCol; i <= entityRightCol; i++) {
            try {
                aux = map.getTileID(j, i);
                for (int k : TILE_COLLISION)
                    if (k == aux) {
                        ok = true;
                        break;
                    }
            }
            catch(MatrixIndexOutOfBounds e) {
                System.out.println(e.getMessage());
                e.printStackTrace();
            }
        }
        return ok;
    }

    public static boolean checkTileDown(Entity entity, Map map) {
        int entityLeftWorldX = entity.worldX + entity.solidArea.x;
        int entityRightWorldX = entity.worldX + entity.solidArea.x + entity.solidArea.width;
        int entityTopWorldY = entity.worldY + entity.solidArea.y;
        int entityBottomWorldY = entity.worldY + entity.solidArea.y + entity.solidArea.height;

        int entityLeftCol = entityLeftWorldX / ACTUAL_TILE_WIDTH;
        int entityRightCol = entityRightWorldX / ACTUAL_TILE_WIDTH;
        int entityTopRow = entityTopWorldY / ACTUAL_TILE_HEIGHT;
        int entityBottomRow = entityBottomWorldY / ACTUAL_TILE_HEIGHT;
        int j;
        int i;
        int aux;
        boolean ok = false;
        j = (entityBottomWorldY + entity.speed) / ACTUAL_TILE_HEIGHT;
        for (i = entityLeftCol; i <= entityRightCol; i++) {
            try {
            aux = map.getTileID(j, i);

                for (int k : TILE_COLLISION)
                    if (k == aux) {
                        ok = true;
                        break;
                    }
            }
            catch(MatrixIndexOutOfBounds e) {
                System.out.println(e.getMessage());
                e.printStackTrace();
            }
        }
        return ok;
    }

    public static boolean checkTileRight(Entity entity, Map map) {

        int entityRightWorldX = entity.worldX + entity.solidArea.x + entity.solidArea.width;
        int entityTopWorldY = entity.worldY + entity.solidArea.y;
        int entityBottomWorldY = entity.worldY + entity.solidArea.y + entity.solidArea.height;
        int entityTopRow = entityTopWorldY / ACTUAL_TILE_HEIGHT;
        int entityBottomRow = entityBottomWorldY / ACTUAL_TILE_HEIGHT;

        int j;
        int i;
        int aux;
        boolean ok = false;
        j = (entityRightWorldX + entity.speed) / ACTUAL_TILE_WIDTH;
        for (i = entityTopRow; i <= entityBottomRow; i++) {
            try {
                aux = map.getTileID(i, j);

                for (int k : TILE_COLLISION)
                    if (k == aux) {
                        ok = true;
                        break;
                    }
            }
            catch(MatrixIndexOutOfBounds e) {
                System.out.println(e.getMessage());
                e.printStackTrace();
            }
        }
        return ok;
    }

    public static boolean checkTileLeft(Entity entity, Map map) {
        int entityLeftWorldX = entity.worldX + entity.solidArea.x;
        int entityTopWorldY = entity.worldY + entity.solidArea.y;
        int entityBottomWorldY = entity.worldY + entity.solidArea.y + entity.solidArea.height;
        int entityTopRow = entityTopWorldY / ACTUAL_TILE_HEIGHT;
        int entityBottomRow = entityBottomWorldY / ACTUAL_TILE_HEIGHT;

        int j;
        int i;
        int aux;
        boolean ok = false;
        j = (entityLeftWorldX - entity.speed) / ACTUAL_TILE_WIDTH;
        for (i = entityTopRow; i <= entityBottomRow; i++) {
            try {
                aux = map.getTileID(i, j);
                for (int k : TILE_COLLISION)
                    if (k == aux) {
                        ok = true;
                        break;
                    }
            }
            catch(MatrixIndexOutOfBounds e) {
                System.out.println(e.getMessage());
                e.printStackTrace();
            }
        }
        return ok;
    }

    public static int checkObject(Entity entity, AbstractObject[] objects) {
        int index = -1;

        for (int i = 0; i < objects.length; i++) {
            if (objects[i] != null) {
                //Get entity's solid area position
                entity.solidArea.x = entity.worldX + entity.solidArea.x;
                entity.solidArea.y = entity.worldY + entity.solidArea.y;
                //Get object's solid area position
                objects[i].solidArea.x = objects[i].getWorldX() + objects[i].solidArea.x;
                objects[i].solidArea.y = objects[i].getWorldY() + objects[i].solidArea.y;
                if (entity.solidArea.intersects(objects[i].solidArea)) {
                    index = i;

                }
                entity.solidArea.x = entity.solidAreaDefaultX;
                entity.solidArea.y = entity.solidAreaDefaultY;
                objects[i].solidArea.x = objects[i].solidAreaDefaultX;
                objects[i].solidArea.y = objects[i].solidAreaDefaultY;
                if (index != -1)
                    break;
            }

        }

        return index;
    }

    //Monster collision
    public static int checkEntity(Entity entity, AbstractMonster[] target) {
        int index = -1;

        for (int i = 0; i < target.length; i++) {
            if (target[i] != null && entity != target[i]) {
                //Get entity's solid area position
                entity.solidArea.x = entity.worldX + entity.solidArea.x;
                entity.solidArea.y = entity.worldY + entity.solidArea.y;
                //Get object's solid area position
                target[i].solidArea.x = target[i].getWorldX() + target[i].solidArea.x;
                target[i].solidArea.y = target[i].getWorldY() + target[i].solidArea.y;

                if (entity.direction.equals("right")) {
                    entity.solidArea.x += entity.speed;
                    if (entity.solidArea.intersects(target[i].solidArea)) {
                        entity.collisionOn = true;
                        index = i;
                    }
                } else if (entity.direction.equals("left")) {
                    entity.solidArea.x += entity.speed;
                    if (entity.solidArea.intersects(target[i].solidArea)) {
                        entity.collisionOn = true;
                        index = i;
                    }
                }
                entity.solidArea.x = entity.solidAreaDefaultX;
                if (index == -1 && entity.jump == true) {
                    entity.solidArea.y -= entity.speed;
                    if (entity.solidArea.intersects(target[i].solidArea)) {
                        entity.collisionOn = true;
                        index = i;
                    }
                }
                entity.solidArea.y = entity.solidAreaDefaultY;
                target[i].solidArea.x = target[i].solidAreaDefaultX;
                target[i].solidArea.y = target[i].solidAreaDefaultY;
                if (index != -1)
                    break;
            }
        }
        return index;
    }

    public static boolean checkPlayer(Entity entity, PlayerLevel1 player) {
        //Get entity's solid area position
        entity.solidArea.x = entity.worldX + entity.solidArea.x;
        entity.solidArea.y = entity.worldY + entity.solidArea.y;
        //Get object's solid area position
        player.solidArea.x = player.worldX + player.solidArea.x;
        player.solidArea.y = player.worldY + player.solidArea.y;

        if (entity.direction.equals("right")) {
            entity.solidArea.x += entity.speed;
            if (entity.solidArea.intersects(player.solidArea)) {
                entity.collisionOn = true;
            }
        } else if (entity.direction.equals("left")) {
            entity.solidArea.x += entity.speed;
            if (entity.solidArea.intersects(player.solidArea)) {
                entity.collisionOn = true;

            }
        }
        entity.solidArea.x = entity.solidAreaDefaultX;
        if (entity.jump == true) {
            entity.solidArea.y -= entity.speed;
            if (entity.solidArea.intersects(player.solidArea)) {
                entity.collisionOn = true;

            }
        }
        entity.solidArea.y = entity.solidAreaDefaultY;
        player.solidArea.x = player.solidAreaDefaultX;
        player.solidArea.y = player.solidAreaDefaultY;
        return entity.collisionOn;
    }
}

