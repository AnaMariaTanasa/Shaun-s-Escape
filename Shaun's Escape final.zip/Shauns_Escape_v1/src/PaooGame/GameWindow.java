package PaooGame;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;


/*! \class GameWindow
    \brief Implementeaza notiunea de fereastra a jocului.

    Membrul wndFrame este un obiect de tip JFrame care va avea utilitatea unei
    ferestre grafice si totodata si cea a unui container (toate elementele
    grafice vor fi continute de fereastra).
 */
public class GameWindow
{
    private JFrame wndFrame1;       /*!< fereastra principala a jocului*/
    private JFrame wndFrame2;
    private String  wndTitle;       /*!< titlul ferestrei*/
    private int     wndWidth;       /*!< latimea ferestrei in pixeli*/
    private int     wndHeight;      /*!< inaltimea ferestrei in pixeli*/
    private CanvasWithBackground canvas1;         /*!< "panza/tablou" in care se poate desena*/
    private Canvas canvas2;         /*!< "panza/tablou" in care se poate desena*/

    public JButton newGameButton;
    public JButton loadGameButton;
    private ActionListenerClass newGameListener;
    private ActionListenerClass loadGameListener;
    //Crearea obiectului va trebui urmata de crearea ferestrei propriuzise prin apelul metodei BuildGameWindow()
    public GameWindow(String title, int width, int height){
        wndTitle    = title;    /*!< Retine titlul ferestrei.*/
        wndWidth    = width;    /*!< Retine latimea ferestrei.*/
        wndHeight   = height;   /*!< Retine inaltimea ferestrei.*/
        wndFrame1 = null;     /*!< Fereastra nu este construita.*/
        wndFrame2 = null;
        newGameListener=null;
        loadGameListener=null;
    }
    public JFrame GetJFRame(int index)
    {
        if(index==1)
            return wndFrame1;
        return wndFrame2;
    }
    public void BuildGameWindow(int index,KeyHandler kh,int level)
    {
        if(index==1) {
            if (wndFrame1 != null) {
                return;
            }
            /// Aloca memorie pentru obiectul de tip fereastra si seteaza denumirea
            /// ce apare in bara de titlu
            wndFrame1 = new JFrame(wndTitle);

            /// Seteaza dimensiunile ferestrei in pixeli
            wndFrame1.setSize(wndWidth, wndHeight);
            /// Operatia de inchidere (fereastra sa poata fi inchisa atunci cand
            /// este apasat butonul worldX din dreapta sus al ferestrei). Totodata acest
            /// lucru garanteaza ca nu doar fereastra va fi inchisa ci intregul
            /// program
            wndFrame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            wndFrame1.setResizable(false);
            // Pentru orice alte pozitie se va apela "wndFrame.setLocation(worldX, y)" etc.
            wndFrame1.setLocationRelativeTo(null);
            // wndFrame1.setVisible(true);
            wndFrame1.addKeyListener(kh);
            wndFrame1.setFocusable(true);

            /// Creaza obiectul de tip canvas (panza) pe care se poate desena.
            if(level==1)
                canvas1 = new CanvasWithBackground("/textures/farm-background.jpg");
            else if(level==2)
                canvas1 = new CanvasWithBackground("/textures/cave_background.jpg");
            else
                canvas1 = new CanvasWithBackground("/textures/forest_background.jpg");
            canvas1.setPreferredSize(new Dimension(wndWidth, wndHeight));
            /// Avand in vedere ca elementele unei ferestre pot fi scalate atunci cand
            /// fereastra este redimensionata
            canvas1.setMaximumSize(new Dimension(wndWidth, wndHeight));
            canvas1.setMinimumSize(new Dimension(wndWidth, wndHeight));
            canvas1.setBackground(Color.BLUE);
            wndFrame1.add(canvas1);


            /// Urmatorul apel de functie are ca scop eventuala redimensionare a ferestrei
            /// ca tot ce contine sa poate fi afisat complet
            wndFrame1.pack();


            wndFrame1.revalidate();
            wndFrame1.repaint();
        }
        else if(index==2) {
            if (wndFrame2 != null) {
                return;
            }
            /// Aloca memorie pentru obiectul de tip fereastra si seteaza denumirea
            /// ce apare in bara de titlu
            wndFrame2 = new JFrame(wndTitle);

            /// Seteaza dimensiunile ferestrei in pixeli
            wndFrame2.setSize(wndWidth, wndHeight);
            /// Operatia de inchidere (fereastra sa poata fi inchisa atunci cand
            /// este apasat butonul worldX din dreapta sus al ferestrei). Totodata acest
            /// lucru garanteaza ca nu doar fereastra va fi inchisa ci intregul
            /// program
            wndFrame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            wndFrame2.setResizable(false);
            // Pentru orice alte pozitie se va apela "wndFrame.setLocation(worldX, y)" etc.
            wndFrame2.setLocationRelativeTo(null);
            // wndFrame2.setVisible(true);
            wndFrame2.addKeyListener(kh);
            wndFrame2.setFocusable(true);

            /// Creaza obiectul de tip canvas (panza) pe care se poate desena.
            // canvas2 = new CanvasWithBackground("/res/textures/menu_background.png");
            canvas2 = new Canvas();
            canvas2.setPreferredSize(new Dimension(wndWidth, wndHeight));
            /// Avand in vedere ca elementele unei ferestre pot fi scalate atunci cand
            /// fereastra este redimensionata
            canvas2.setMaximumSize(new Dimension(wndWidth, wndHeight));
            canvas2.setMinimumSize(new Dimension(wndWidth, wndHeight));
            //canvas2.setBackground(Color.BLUE);
            wndFrame2.add(canvas2);


            newGameButton= new JButton("New Game");

            loadGameButton= new JButton("Load Game");


            JPanelWithBackground panel = new JPanelWithBackground("/textures/menu_background.png");
            panel.setPreferredSize(new Dimension(wndWidth, wndHeight));
            newGameButton.setPreferredSize(new Dimension(200,50));
            newGameListener=new ActionListenerClass();
            loadGameListener=new ActionListenerClass();
            newGameButton.addActionListener(newGameListener);
            loadGameButton.addActionListener(loadGameListener);
            //newGameButton.setBackground(Color.GRAY);
            loadGameButton.setPreferredSize(new Dimension(200,50));
            panel.add(newGameButton);
            panel.add(loadGameButton);
            wndFrame2.add(panel);
            //wndFrame2.add(loadGameButton);


            /// Urmatorul apel de functie are ca scop eventuala redimensionare a ferestrei
            /// ca tot ce contine sa poate fi afisat complet
            wndFrame2.pack();


            wndFrame2.revalidate();
            wndFrame2.repaint();
        }
    }





    public KeyHandler getKeyHandler()
    {
        return (KeyHandler) wndFrame1.getKeyListeners()[0];
    }
    public void KeyHandlerInput()
    {
        if(getKeyHandler().up)
            System.out.println("Game Window up");
        if(getKeyHandler().down)
            System.out.println("Game Window down");
        if(getKeyHandler().left)
            System.out.println("Game Window left");
    }
    public int GetWndWidth()
    {
        return wndWidth;
    }
    public int GetWndHeight()
    {
        return wndHeight;
    }
    public Canvas GetCanvas(int index) {
        if(index==1)
            return canvas1;
        return  canvas2;
    }
    public void setVisibleButton(int index,boolean vis)//makes button visible or invisible ,chooses the button based on index
    {
        if(index==1)
        {
            newGameButton.setVisible(vis);
        }
        else
        {
            loadGameButton.setVisible(vis);
        }
    }
    public ActionListenerClass getActionListener(int index)
    {
        if(index==1)
            return newGameListener;
        return loadGameListener;
    }
}
