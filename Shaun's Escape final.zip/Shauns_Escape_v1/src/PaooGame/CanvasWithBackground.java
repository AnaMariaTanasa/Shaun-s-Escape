package PaooGame;

import PaooGame.Graphics.ImageLoader;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;

/** extends the Canvas class to add a bkg image */
public class CanvasWithBackground extends Canvas {
    private BufferedImage backgroundImage;

    public CanvasWithBackground(String imagePath) {
        try {
            backgroundImage = ImageLoader.LoadImage(imagePath);
        }
        catch(NullPointerException n)
        {
            System.out.println("Can't load image " + imagePath);
        }

    }
    public void changeImage(String imagePath)
    {
        backgroundImage = ImageLoader.LoadImage(imagePath);
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);

        // Draw the background image
        g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
    }
}