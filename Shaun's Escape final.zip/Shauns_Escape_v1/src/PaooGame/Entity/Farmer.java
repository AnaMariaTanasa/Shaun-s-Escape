package PaooGame.Entity;

import PaooGame.CollisionChecker;
import PaooGame.Graphics.Map;
import PaooGame.Main;

import java.awt.*;

import static PaooGame.Graphics.Assets.*;
import static PaooGame.Graphics.Assets.farmerIdle;
import static java.lang.Math.abs;

public class Farmer extends AbstractMonster{
    public void draw(Graphics g, PlayerLevel1 player) {
        int screenX=worldX- player.worldX+ player.screenX;
        int screenY=worldY- player.worldY+ player.screenY;
        if(worldX+entityWidth> player.worldX- player.screenX &&
                worldX-entityWidth< player.worldX+ player.screenX &&
                worldY+entityHeight> player.worldY- player.screenY &&
                worldY-entityHeight< player.worldY+ player.screenY)
        {
            if(spriteNum<2)
            {
                if(direction.equals("right") && attack==false)
                    g.drawImage(farmerWalkRight[spriteNum], screenX,screenY,entityWidth,entityHeight,null);
                else if(direction.equals("left") && attack==false )
                    g.drawImage(farmerWalkLeft[spriteNum],  screenX,screenY,entityWidth,entityHeight,null);
                else if(direction.equals("right") && attack==true)
                    g.drawImage(farmerAttackRight[spriteNum], screenX,screenY,entityWidth,entityHeight,null);
                else if(direction.equals("left") && attack==true)
                    g.drawImage(farmerWalkLeft[spriteNum],  screenX,screenY,entityWidth,entityHeight,null);
                else
                    g.drawImage(farmerIdle, screenX,screenY,entityWidth,entityHeight,null);
            }
        }
        //g.drawRect(screenX+solidArea.x,screenY+solidArea.y,solidArea.width, solidArea.height);
    }

    @Override
    public void update(PlayerLevel1 player,Map map,AbstractMonster[] monsters){
        if(worldX>10 && worldX<(map.nr_cols-3)*32 && worldY>10 && worldY<(map.nr_rows-3)*32) {
            collisionOn = false;
            if (spriteCounter > 20) {
                spriteCounter = 0;
            }
            changeLockCounter++;
            if (changeLockCounter > 60) {
                double rand = Math.random() * 100;
                //System.out.println(rand+"1234");
                if (rand > 50)
                    direction = "right";
                else
                    direction = "left";
                if (CollisionChecker.checkPlayer(this, player))
                    attack = true;
                else
                    attack = false;
                changeLockCounter = 0;
            }

            collisionOn = false;
            if (collisionOn == false)
                CollisionChecker.checkTile(this, map);
            if (collisionOn == false)
                CollisionChecker.checkPlayer(this, player);
            if (collisionOn == false) {
                int index = CollisionChecker.checkEntity(this, monsters);
                if (index == -1) {
                    if (direction.equals("right"))
                        worldX += speed;
                    if (direction.equals("left"))
                        worldX -= speed;
                } else {
                    if (monsters[index].worldX > this.worldX) {
                        direction = "left";
                        worldX -= speed;
                    } else {
                        direction = "right";
                        worldX += speed;
                    }
                }


            }

            if ((CollisionChecker.checkTileDown(this, map) == false)) {
                worldY += speed;
            }
            spriteCounter++;
            if (spriteCounter == 20) {
                switch (spriteNum) {
                    case 0:
                        spriteNum++;
                        break;
                    case 1:
                        spriteNum = 0;
                        break;
                }

            }
        }
        else
        {
            if(worldX>=(map.nr_cols-3)/32 )
            {

                worldX=(map.nr_cols-4)/32;
            }
             if(worldY>=(map.nr_cols-3)/32 )
            {

                worldY=(map.nr_cols-4)/32;
            }
             if( worldX<=10 )
            {

                worldX=15;
            }
            if( worldY<=10 )
            {
                worldY=15;

            }
        }
    }
    public Farmer(int life)
    {
        super(life);
        damage=2;
        speed=2;
        entityWidth=64;
        entityHeight=64;
        solidArea=new Rectangle(7,10,entityWidth-15,entityHeight-20);
        solidAreaDefaultX=solidArea.x;
        solidAreaDefaultY=solidArea.y;
    }
}
