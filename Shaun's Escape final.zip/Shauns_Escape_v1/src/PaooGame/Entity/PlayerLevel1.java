package PaooGame.Entity;

import PaooGame.CollisionChecker;
import PaooGame.Graphics.Map;
import PaooGame.KeyHandler;
import PaooGame.Main;
import PaooGame.Objects.ObjectInventory;

import static PaooGame.Graphics.Assets.*;
import static PaooGame.Tiles.Tile.*;

import java.awt.*;
import java.awt.image.BufferedImage;



public class PlayerLevel1 extends Entity {

    protected KeyHandler keyHandler1;
    public static final int PLAYER_WIDTH = 250;
    public static final int PLAYER_HEIGHT = 180;
    public boolean powerUp1Active;
    public boolean powerUp2Active;
    public int counterPowerup1;
    public boolean GetKhUp(){return keyHandler1.up;}
    public boolean GetKhRight(){return keyHandler1.right;}
    public boolean GetKhLeft(){return keyHandler1.left;}
    public boolean GetKhShift(){return keyHandler1.shift;}
    public PlayerLevel1(int life,int Speed,KeyHandler kh,int wx,int wy)
    {
        super(life);
        screenX= Main.width/2-PlayerLevel1.PLAYER_WIDTH/4;
        screenY=Main.height/2-PlayerLevel1.PLAYER_HEIGHT/4;
        worldX=wx;
        worldY=wy;
        speed=Speed;
        solidArea=new Rectangle(15,0,PLAYER_WIDTH/3-30,PLAYER_HEIGHT/3-10);
        solidAreaDefaultX=solidArea.x;
        solidAreaDefaultY=solidArea.y;
        damage=10;
        keyHandler1=kh;
        powerUp1Active=false;
        powerUp2Active=false;

    }

    public void Draw(Graphics g)
    {

        //wtem.out.println("Draw player x "+worldX+" y "+worldY);
        if(spriteNum<4)
        {
            if(powerUp1Active==false) {
                if (direction.equals("right") && jump == true && attack == false)
                    g.drawImage(shaunJumpRight[spriteNum], screenX, screenY, PLAYER_WIDTH / 3, PLAYER_HEIGHT / 3, null);
                else if (direction.equals("left") && jump == true && attack == false)
                    g.drawImage(shaunJumpLeft[spriteNum], screenX, screenY, PLAYER_WIDTH / 3, PLAYER_HEIGHT / 3, null);
                else if (direction.equals("right") && jump == false && attack == false)
                    g.drawImage(shaunWalkRight[spriteNum], screenX, screenY, PLAYER_WIDTH / 3, PLAYER_HEIGHT / 3, null);
                else if (direction.equals("left") && jump == false && attack == false)
                    g.drawImage(shaunWalkLeft[spriteNum], screenX, screenY, PLAYER_WIDTH / 3, PLAYER_HEIGHT / 3, null);
                else if (attack == true && direction.equals("right"))
                    g.drawImage(shaunAttackRight, screenX, screenY, PLAYER_WIDTH / 3, PLAYER_HEIGHT / 3, null);
                else if (attack == true && direction.equals("left"))
                    g.drawImage(shaunAttackLeft, screenX, screenY, PLAYER_WIDTH / 3, PLAYER_HEIGHT / 3, null);
                else
                    g.drawImage(shaunIdle, screenX, screenY, PLAYER_WIDTH / 3, PLAYER_HEIGHT / 3, null);
            }
            else if(powerUp1Active==true)
            {
                if (direction.equals("right") && jump == true && attack == false)
                g.drawImage(shirleyJumpRight[spriteNum], screenX, screenY, PLAYER_WIDTH / 3, PLAYER_HEIGHT / 3, null);
                else if (direction.equals("left") && jump == true && attack == false)
                g.drawImage(shirleyJumpLeft[spriteNum], screenX, screenY, PLAYER_WIDTH / 3, PLAYER_HEIGHT / 3, null);
            else if (direction.equals("right") && jump == false && attack == false)
                g.drawImage(shirleyWalkRight[spriteNum], screenX, screenY, PLAYER_WIDTH / 3, PLAYER_HEIGHT / 3, null);
            else if (direction.equals("left") && jump == false && attack == false)
                g.drawImage(shirleyWalkLeft[spriteNum], screenX, screenY, PLAYER_WIDTH / 3, PLAYER_HEIGHT / 3, null);
            else if (attack == true && direction.equals("right"))
                g.drawImage(shirleyAttackRight, screenX, screenY, PLAYER_WIDTH / 3, PLAYER_HEIGHT / 3, null);
            else if (attack == true && direction.equals("left"))
                g.drawImage(shirleyAttackLeft, screenX, screenY, PLAYER_WIDTH / 3, PLAYER_HEIGHT / 3, null);
            else
                g.drawImage(shirleyIdleRight, screenX, screenY, PLAYER_WIDTH / 3, PLAYER_HEIGHT / 3, null);
            }
        }


    }
    /** updates player based on map, monsters and inventory */
    public void PlayerUpdate(Map map, AbstractMonster[] monsters, ObjectInventory objectInventory)  {
        if (spriteCounter>20)
        {
            spriteCounter=0;
        }

        //direction is decided

        if(keyHandler1.caps==true && objectInventory.nrPowerup1>0)
        {
            powerUp1Active=true;
            counterPowerup1=0;
        }
        if(powerUp1Active)
        {
            counterPowerup1++;
            if(counterPowerup1>60)
            {
                powerUp1Active=false;
            }
        }
        if (keyHandler1.up)
        {
            jump = true;
        }
        else
        {
            jump=false;
        }

        if (keyHandler1.right)
        {
            direction = "right";
        }
        if(keyHandler1.shift)
        {
            attack=true;
        }
        else
        {
            attack=false;
        }
        if (keyHandler1.left)
        {
            direction = "left";
        }
        if(keyHandler1.left==false && keyHandler1.right==false)
            direction="";

        collisionOn=false;
        CollisionChecker.checkTile(this,map);


        //if collisionOn=false;player can move

        if(collisionOn==false)
        {
            int monsterIndex=CollisionChecker.checkEntity(this,monsters);
            if(jump==true && (direction.equals("right") || direction.equals("left")))
                worldY-=speed;
            else
                jump=false;
            //if the player can move without colliding again with a monster
            if(direction.equals("right") && ((monsterIndex!=-1 && monsters[monsterIndex].worldX<=worldX) || monsterIndex==-1) && jump==false )
                worldX+=speed;
            else if(direction.equals("right") && jump==true)
                worldX+=speed;
            if(direction.equals("left") && ((monsterIndex!=-1 && monsters[monsterIndex].worldX>=worldX) || monsterIndex==-1) && jump==false)
                worldX-=speed;
            else if(direction.equals("left") && jump==true)
                worldX-=speed;
        }
        if((CollisionChecker.checkTileDown(this,map)==false) && jump==false) //gravity
        {
            worldY+=speed;
        }

        //keeps player on map
        if (worldX < 0)
            worldX = 0;
        if (worldY <0)
            worldY = 0;
        if (worldX > Map.nr_cols*ACTUAL_TILE_WIDTH)
            worldX = Map.nr_cols*ACTUAL_TILE_WIDTH;
        if (worldY >  Map.nr_rows*ACTUAL_TILE_WIDTH)
            worldY = Map.nr_rows*ACTUAL_TILE_WIDTH;
        spriteCounter++;
        if (spriteCounter == 20) {
            switch (spriteNum) {
                case 0:
                case 1:
                case 2:
                    spriteNum++;
                    break;
                case 3:
                    spriteNum = 0;
                    break;
            }

        }
    }
    /**effect on monster at collision*/
    public void contactMonster(AbstractMonster monster)
    {
        if(attackCounter>40) //timing attacks
            attackCounter=0;
        if(attackCounter==0) {
            if (powerUp1Active) {
                monster.life = monster.life - damage * 4;
            } else if (powerUp2Active) {
                monster.life = 0;
            }else if(attack)
            {
                monster.life=monster.life -2*damage;
            }
            else {
                monster.life -= damage;
            }
        }
        attackCounter++;

    }
}
