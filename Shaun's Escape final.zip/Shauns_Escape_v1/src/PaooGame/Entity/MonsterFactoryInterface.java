package PaooGame.Entity;


public interface MonsterFactoryInterface {
    public AbstractMonster getMonster(String type,int life);
}
