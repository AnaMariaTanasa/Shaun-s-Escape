package PaooGame.Entity;

import PaooGame.Graphics.Map;

import java.awt.*;

public abstract class AbstractMonster extends Entity { //Abstract class for monsters. Primary usage:monsterFactory
    protected int entityHeight;
    protected int entityWidth;
    public int changeLockCounter; //used for timing direction changes

    public AbstractMonster(int life) {
        super(life);
        changeLockCounter = 0;
    }

    abstract public void draw(Graphics g, PlayerLevel1 player);

    abstract public void update(PlayerLevel1 player, Map map, AbstractMonster[] monsters);

    public void setWorldX(int x) {
        worldX = x;
    }

    public void setWorldY(int y) {
        worldY = y;
    }

    public int getWorldX() {
        return worldX;
    }

    public int getWorldY() {
        return worldY;
    }

    public void contactPlayer(PlayerLevel1 player) {
        if(attackCounter>180) //attack timing
            attackCounter=0;
        if (player.powerUp1Active==false && attackCounter==0 && (player.direction.equals("right") && direction.equals("left")) || (player.direction.equals("left") && direction.equals("right"))) {
            player.life -= damage;
        }
        attackCounter++;
    }
}
