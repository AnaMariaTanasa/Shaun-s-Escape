package PaooGame.Entity;

import PaooGame.Objects.AbstractObject;
import PaooGame.Objects.ObjectFactory;

import static PaooGame.Tiles.Tile.ACTUAL_TILE_HEIGHT;
import static PaooGame.Tiles.Tile.ACTUAL_TILE_WIDTH;

public class MonsterSetter {

    /** sets the monsters on the map using a monster factory; the monsters' positions are hardcoded*/
    public static void setMonsters(int level, AbstractMonster[] monsters,String monsterLife,String monsterType)
    {
        MonsterFactory factory=new MonsterFactory();
        /** splits strings obtained from database */
        String[] monsterNames=monsterType.split(" ");
        String[] monsterLifes=monsterLife.split(",");
        for(int i=0;i<monsters.length;i++)
        {
            if(Integer.parseInt(monsterLifes[i])!=0) //if monster has life
            {
                monsters[i]= factory.getMonster(monsterNames[i],Integer.parseInt(monsterLifes[i]));
            }
        }
        if(level==1)
        {
            if(monsters[0]!=null) {
                monsters[0].setWorldX(11 * ACTUAL_TILE_WIDTH);
                monsters[0].setWorldY(9 * ACTUAL_TILE_HEIGHT);
            }
            if(monsters[1]!=null) {
                monsters[1].setWorldX(25 * ACTUAL_TILE_WIDTH);
                monsters[1].setWorldY(12 * ACTUAL_TILE_HEIGHT);
            }
            if(monsters[2]!=null) {
                monsters[2].setWorldX(50 * ACTUAL_TILE_WIDTH);
                monsters[2].setWorldY(9 * ACTUAL_TILE_HEIGHT);
            }
            if(monsters[3]!=null) {
                monsters[3].setWorldX(100 * ACTUAL_TILE_WIDTH);
                monsters[3].setWorldY(12 * ACTUAL_TILE_HEIGHT);
            }
        }
        else if (level==2)
        {
            if(monsters[0]!=null) {
                monsters[0].setWorldX(19 * ACTUAL_TILE_WIDTH);
                monsters[0].setWorldY(4 * ACTUAL_TILE_HEIGHT);
            }
            if(monsters[1]!=null) {
                monsters[1].setWorldX(28 * ACTUAL_TILE_WIDTH);
                monsters[1].setWorldY(11 * ACTUAL_TILE_HEIGHT);
            }
            if(monsters[2]!=null) {
                monsters[2].setWorldX(51 * ACTUAL_TILE_WIDTH);
                monsters[2].setWorldY(6 * ACTUAL_TILE_HEIGHT);
            }
            if(monsters[3]!=null) {
                monsters[3].setWorldX(12 * ACTUAL_TILE_WIDTH);
                monsters[3].setWorldY(18 * ACTUAL_TILE_HEIGHT);
            }
            if(monsters[4]!=null) {
                monsters[4].setWorldX(29 * ACTUAL_TILE_WIDTH);
                monsters[4].setWorldY(18 * ACTUAL_TILE_HEIGHT);
            }
            if(monsters[5]!=null) {
                monsters[5].setWorldX(52 * ACTUAL_TILE_WIDTH);
                monsters[5].setWorldY(25 * ACTUAL_TILE_HEIGHT);
            }
        }
        else{
            if(monsters[0]!=null) {
                monsters[0].setWorldX(13 * ACTUAL_TILE_WIDTH);
                monsters[0].setWorldY(4 * ACTUAL_TILE_HEIGHT);
            }
            if(monsters[1]!=null) {
                monsters[1].setWorldX(8 * ACTUAL_TILE_WIDTH);
                monsters[1].setWorldY(13 * ACTUAL_TILE_HEIGHT);
            }
            if(monsters[2]!=null) {
                monsters[2].setWorldX(57 * ACTUAL_TILE_WIDTH);
                monsters[2].setWorldY(12 * ACTUAL_TILE_HEIGHT);
            }
            if(monsters[3]!=null) {
                monsters[3].setWorldX(25 * ACTUAL_TILE_WIDTH);
                monsters[3].setWorldY(4 * ACTUAL_TILE_HEIGHT);
            }
            if(monsters[4]!=null) {
                monsters[4].setWorldX(46 * ACTUAL_TILE_WIDTH);
                monsters[4].setWorldY(12 * ACTUAL_TILE_HEIGHT);
            }
            if(monsters[5]!=null) {
                monsters[5].setWorldX(100 * ACTUAL_TILE_WIDTH);
                monsters[5].setWorldY(10 * ACTUAL_TILE_HEIGHT);
            }
            if(monsters[6]!=null) {
                monsters[6].setWorldX(122 * ACTUAL_TILE_WIDTH);
                monsters[6].setWorldY(12 * ACTUAL_TILE_HEIGHT);
            }

        }
    }
}
