package PaooGame.Entity;

import PaooGame.CollisionChecker;
import PaooGame.Graphics.Map;
import PaooGame.Main;

import java.awt.*;

import static PaooGame.Graphics.Assets.*;
import static PaooGame.Tiles.Tile.ACTUAL_TILE_HEIGHT;
import static PaooGame.Tiles.Tile.ACTUAL_TILE_WIDTH;
import static java.lang.Math.abs;

public class Alien extends AbstractMonster{
    @Override
    public void draw(Graphics g,PlayerLevel1 player) {
        int screenX=worldX- player.worldX+ player.screenX;
        int screenY=worldY- player.worldY+ player.screenY;
        /** screenX, screenY monster coordinates on screen
         * if for checking if the monster in now visible
         */
        if(worldX+entityWidth> player.worldX- player.screenX &&
                worldX-entityWidth< player.worldX+ player.screenX &&
                worldY+entityHeight> player.worldY- player.screenY &&
                worldY-entityHeight< player.worldY+ player.screenY)
        {
            if(spriteNum<2)
            {
                if(direction.equals("right") && attack==false)
                    g.drawImage(alienWalkRight[spriteNum], screenX,screenY,entityWidth,entityHeight,null);
                else if(direction.equals("left") && attack==false )
                    g.drawImage(alienWalkLeft[spriteNum],  screenX,screenY,entityWidth,entityHeight,null);
                else if(direction.equals("right") && attack==true)
                    g.drawImage(alienAttackRight[spriteNum], screenX,screenY,entityWidth,entityHeight,null);
                else if(direction.equals("left") && attack==true)
                    g.drawImage(alienWalkLeft[spriteNum],  screenX,screenY,entityWidth,entityHeight,null);
                else
                    g.drawImage(alienIdleRight, screenX,screenY,entityWidth,entityHeight,null);
            }
        }
    }

    @Override
    public void update(PlayerLevel1 player,Map map,AbstractMonster[] monsters) /** updates monster using player,map and the other monsters */
    {
        /**if  the monster is on the map */
        if(worldX>=10 && worldX<=(map.nr_cols-3)*32 && worldY>=10 && worldY<=(map.nr_rows-3)*32) {
            collisionOn = false;
            if (spriteCounter > 20) {
                spriteCounter = 0;
            }
            changeLockCounter++;
            /** timing a change in direction */
            if (changeLockCounter > 60) {
                /** attempt to follow the player if it's visible to the monster(is in the same screen)*/
                if (abs(worldX - player.worldX) < Main.width / 2 && abs(worldY - player.worldY) < Main.height / 2) {
                    if (player.worldX > worldX)
                        direction = "right";

                    if (player.worldX < worldX)
                        direction = "left";

                }
                if (CollisionChecker.checkPlayer(this, player))
                    attack = true;
                else
                    attack = false;


                changeLockCounter = 0;
            }

            if (collisionOn == false)
                CollisionChecker.checkTile(this, map);
            CollisionChecker.checkPlayer(this, player);
            if (collisionOn == false) {
                int index = CollisionChecker.checkEntity(this, monsters);
                if (index == -1) { //if this monster has no current collision with other monsters, it can move freely
                    if (direction.equals("right"))
                        worldX += speed;
                    if (direction.equals("left"))
                        worldX -= speed;
                    if (jump == true)
                        worldY -= speed;
                } else { //the monster has collision with other entity, then it goes in the other direction to avoid collision
                    if (monsters[index].worldX > this.worldX) {
                        direction = "left";
                        worldX -= speed;
                    } else {
                        direction = "right";
                        worldX += speed;
                    }
                }


            }

            if ((CollisionChecker.checkTileDown(this, map) == false) && jump == false) {
                worldY += speed;
            }
            spriteCounter++;
            if (spriteCounter == 20) {
                switch (spriteNum) {
                    case 0:
                        spriteNum++;
                        break;
                    case 1:
                        spriteNum = 0;
                        break;
                }

            }
        }
        else
        {
            /** adjust the monster's position if it has a tendency to exit the map */
            if(worldX>=(map.nr_cols-3)/32 )
            {

                worldX=(map.nr_cols-4)/32;
            }
            if(worldY>=(map.nr_cols-3)/32 )
            {

                worldY=(map.nr_cols-4)/32;
            }
            if( worldX<=10 )
            {

                worldX=15;
            }
            if( worldY<=10 )
            {
                worldY=15;

            }
        }
    }
    public Alien(int life)
    {
        super(life);
        damage=2;
        speed=1;
        entityWidth=48;
        entityHeight=48;
        /** solidArea for implementing collisions */
        solidArea=new Rectangle(3,0,entityWidth-10,entityHeight);
        solidAreaDefaultX=solidArea.x;
        solidAreaDefaultY=solidArea.y;

    }



}
