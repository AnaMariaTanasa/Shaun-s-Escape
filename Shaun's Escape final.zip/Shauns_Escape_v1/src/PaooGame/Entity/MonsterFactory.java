package PaooGame.Entity;

import PaooGame.Objects.*;

public class MonsterFactory implements MonsterFactoryInterface {

    /** returns an AbstractMonster based on its type and remaining life */
    @Override
    public AbstractMonster getMonster(String type,int life)
    {
        AbstractMonster monster=null;
        switch(type)
        {
            case "Alien":
                monster= new Alien(life);
                break;
            case "Farmer":
                monster= new Farmer(life);
                break;
            case "Wolf":
                monster= new Wolf(life);
                break;
            case "Bear":
                monster= new Bear(life);
                break;

        }
        return monster;
    }
}
