package PaooGame.Entity;

import PaooGame.KeyHandler;
import PaooGame.Main;

import java.awt.*;

public class Entity {
    public int worldX;
    public double life;
    public int worldY;
    public  int screenX;
    public  int screenY;
    public int speed;
    public int spriteNum;
    public int spriteCounter;
    public String direction;
    public boolean jump;
    public Rectangle solidArea;
    public int solidAreaDefaultX, solidAreaDefaultY;
    public boolean collisionOn =false;
    public boolean attack;
    public int damage;
    public int attackCounter;


    protected Entity(double life)
    {
        this.life = life;
        spriteNum=0;
        spriteCounter=0;
        direction="";
        attackCounter=0;
    }
}
