package PaooGame;

import PaooGame.GameWindow.*;

import java.sql.*;


public class Main
{
    public static final int  width=800;
    public static final int  height=600;
    public static void main(String[] args)
    {
        Connection c = null;
        Statement stmt = null;
        try {
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:E:/an 2 AC/PAOO/joc/Shauns_Escape_v1/Shauns_Escape_v1.db");
            stmt = c.createStatement();
        } catch ( Exception e ) {
            System.err.println( e.getClass().getName() + ": " + e.getMessage() );
            System.exit(0);
        }
        //System.out.println("Opened database successfully");
        Game paooGame;
        paooGame = new Game("PaooGame", width, height,c,stmt);
        paooGame.StartGame();

    }


}
