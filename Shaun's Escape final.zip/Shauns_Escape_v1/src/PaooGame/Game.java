package PaooGame;

import static PaooGame.Graphics.Assets.*;
import static java.lang.Thread.sleep;

import  PaooGame.Graphics.Assets;
import PaooGame.Graphics.Map;
import PaooGame.Entity.*;
import PaooGame.Objects.*;

import java.awt.*;
import java.awt.image.BufferStrategy;
import java.sql.*;
import java.util.Arrays;

/*! \class Game
    \brief Clasa principala a intregului proiect. Implementeaza Game - Loop (Update -> Draw)

                ------------
                |           |
                |     ------------
    60 times/s  |     |  Update  |  -->{ actualizeaza variabile, stari, pozitii ale elementelor grafice etc.
        =       |     ------------
     16.7 ms    |           |
                |     ------------
                |     |   Draw   |  -->{ deseneaza totul pe ecran
                |     ------------
                |           |
                -------------
    Implementeaza interfata Runnable:

        public interface Runnable {
            public void run();
        }

    Interfata este utilizata pentru a crea un nou fir de executie avand ca argument clasa Game.
    Clasa Game trebuie sa aiba definita metoda "public void run()", metoda ce va fi apelata
    in noul thread(fir de executie). Mai multe explicatii veti primi la curs.

    In mod obisnuit aceasta clasa trebuie sa contina urmatoarele:
        - public Game();            //constructor
        - private void init();      //metoda privata de initializare
        - private void update();    //metoda privata de actualizare a elementelor jocului
        - private void draw();      //metoda privata de desenare a tablei de joc
        - public run();             //metoda publica ce va fi apelata de noul fir de executie
        - public synchronized void start(); //metoda publica de pornire a jocului
        - public synchronized void stop()   //metoda publica de oprire a jocului
 */
public class Game implements Runnable
{
    int level;
    private GameWindow      wnd;        /*!< Fereastra in care se va desena tabla jocului*/
    private boolean         runState;   /*!< Flag ce starea firului de executie.*/
    private Thread          gameThread; /*!< Referinta catre thread-ul de update si draw al ferestrei*/
    private BufferStrategy  bs;         /*!< Referinta catre un mecanism cu care se organizeaza memoria complexa pentru un canvas.*/
    private Map map;
    private PlayerLevel1 Shaun;
    private KeyHandler keyHandler;
    public CollisionChecker collisionChecker;
    public ObjectInventory objectInventory;
    protected AbstractObject[] objects;
    protected AbstractMonster[] monsters;
    public Connection c;
    public Statement s;
    boolean showMenu;

    /// Sunt cateva tipuri de "complex buffer strategies", scopul fiind acela de a elimina fenomenul de
    /// flickering (palpaire) a ferestrei.
    /// Modul in care va fi implementata aceasta strategie in cadrul proiectului curent va fi triplu buffer-at

    ///                         |------------------------------------------------>|
    ///                         |                                                 |
    ///                 ****************          *****************        ***************
    ///                 *              *   Show   *               *        *             *
    /// [ Ecran ] <---- * Front Buffer *  <------ * Middle Buffer * <----- * Back Buffer * <---- Draw()
    ///                 *              *          *               *        *             *
    ///                 ****************          *****************        ***************

    private Graphics        g;          /*!< Referinta catre un context grafic.*/

    public Game(String title, int width, int height,Connection c,Statement s)
    {
        wnd = new GameWindow(title, width, height);
        runState = false;
        this.c=c;
        this.s=s;



    }

    /*! \fn private void init()
        \brief  Metoda construieste fereastra jocului, initializeaza aseturile, listenerul de tastatura etc.

        Fereastra jocului va fi construita prin apelul functiei BuildGameWindow();
        Sunt construite elementele grafice (assets): dale, player, elemente active si pasive.

     */
    private void InitGame(int index)  {
        ResultSet rs;
        try {
            PreparedStatement ps=c.prepareStatement("SELECT * FROM Stats WHERE ID=?;");
            ps.setInt(1,index);
            rs=ps.executeQuery();
            while(rs.next())
            {
                int level=rs.getInt("Level");
                int life=rs.getInt("Life");
                int wx=rs.getInt("Player_worldX");
                int wy=rs.getInt("Player_worldY");
                String objExist=rs.getString("Obj_Exist");
                String objType=rs.getString("Obj_Type");
                String monsterLife=rs.getString("Monster_Life");
                String monsterType=rs.getString("Monster_Type");
                int nrc=rs.getInt("Obj_inventory");
                int nrp1=rs.getInt("Obj_inventory");
                int nrp2=rs.getInt("Obj_inventory");


                this.level=level;
                map=new Map(level);
                keyHandler=new KeyHandler();
                Shaun=new PlayerLevel1(life,2,keyHandler,wx*32,wy*32);
                objectInventory=new ObjectInventory(nrp1,nrp2,nrc);
                objects=new AbstractObject[15];
                monsters=new AbstractMonster[15];
                wnd = new GameWindow("Schelet Proiect PAOO",Main.width , Main.height);
                /// Este construita fereastra grafica.
                wnd.BuildGameWindow(1,keyHandler,level);
                wnd.BuildGameWindow(2,keyHandler,level);
                /// Se incarca toate elementele grafice (dale)
                Assets.Init();
                ObjectSetter.setObjects(level,objects,objExist,objType);
                MonsterSetter.setMonsters(level,monsters,monsterLife,monsterType);
            }
            rs.close();

            showMenu=true;
        }
        catch(java.sql.SQLException sqle)
        {
            System.out.println(sqle.getMessage() + " Init Game");
        }

    }

    /*! \fn public void run()
        \brief Functia ce va rula in thread-ul creat.

        Aceasta functie va actualiza starea jocului si va redesena tabla de joc (va actualiza fereastra grafica)
     */
    public void run()
    {
        /// Initializeaza obiectul game
        InitGame(2);
        long oldTime = System.nanoTime();   /*!< Retine timpul in nanosecunde aferent frame-ului anterior.*/
        long curentTime;                    /*!< Retine timpul curent de executie.*/

        /// Apelul functiilor Update() & Draw() trebuie realizat la fiecare 16.7 ms
        /// sau mai bine spus de 60 ori pe secunda.

        final int framesPerSecond   = 60; /*!< Constanta intreaga initializata cu numarul de frame-uri pe secunda.*/
        final double timeFrame      = 1000000000 / framesPerSecond; /*!< Durata unui frame in nanosecunde.*/
        /// Atat timp timp cat threadul este pornit Update() & Draw()
        while (runState == true)
        {
            /// Se obtine timpul curent
            curentTime = System.nanoTime();
            /// Daca diferenta de timp dintre curentTime si oldTime mai mare decat 16.6 ms
            if((curentTime - oldTime) > timeFrame)
            {

                /// Actualizeaza pozitiile elementelor
                try {
                    Update();
                    /// Deseneaza elementele grafice in fereastra.
                    Draw();
                }
                catch(ArrayIndexOutOfBoundsException e )
                {

                    System.out.println(e.getMessage()+"1234");
                }
                oldTime = curentTime;
            }
        }

    }

    /*! \fn public synchronized void start()
        \brief Creaza si starteaza firul separat de executie (thread).

        Metoda trebuie sa fie declarata synchronized pentru ca apelul acesteia sa fie semaforizat.
     */
    public synchronized void StartGame()
    {
        if(runState == false)
        {
            /// Se actualizeaza flagul de stare a threadului
            runState = true;
            /// Se construieste threadul avand ca parametru obiectul Game. De retinut faptul ca Game class
            /// implementeaza interfata Runnable. Threadul creat va executa functia run() suprascrisa in clasa Game.
            gameThread = new Thread(this);
            /// Threadul creat este lansat in executie (va executa metoda run())
            gameThread.start();
        }
        else
        {
            /// Thread-ul este creat si pornit deja
            return;
        }
    }

    /*! \fn public synchronized void stop()
        \brief Opreste executie thread-ului.

        Metoda trebuie sa fie declarata synchronized pentru ca apelul acesteia sa fie semaforizat.
     */
    public synchronized void StopGame()
    {
        if(runState == true)
        {
            /// Actualizare stare thread
            runState = false;
            /// Metoda join() arunca exceptii motiv pentru care trebuie incadrata intr-un block try - catch.
            try
            {
                /// Metoda join() pune un thread in asteptare panca cand un altul isi termina executie.
                /// Totusi, in situatia de fata efectul apelului este de oprire a threadului.
                gameThread.join();
            }
            catch(InterruptedException ex)
            {
                /// In situatia in care apare o exceptie pe ecran vor fi afisate informatii utile pentru depanare.
                ex.printStackTrace();
            }

        }
        else
        {
            /// Thread-ul este oprit deja.
            return;
        }
    }

    /*! \fn private void Update()
        \brief Actualizeaza starea elementelor din joc.

        Metoda este declarata privat deoarece trebuie apelata doar in metoda run()
     */
    private void Update()
    {

        Shaun.PlayerUpdate(map,monsters,objectInventory);
        int objectIndex=CollisionChecker.checkObject(Shaun,objects);
        if(objectIndex!=-1)
        {
            objects[objectIndex].effectOnPlayer(Shaun);
            objects[objectIndex].addToInventory(objectInventory);
            objects[objectIndex]=null;
        }
        int monsterIndex=CollisionChecker.checkEntity(Shaun,monsters);
        if(monsterIndex!=-1)
        {
            Shaun.contactMonster( monsters[monsterIndex]);
            monsters[monsterIndex].contactPlayer(Shaun);
        }
        for(int i=0;i<monsters.length;i++)
            if(monsters[i]!=null)
            {
                if(monsters[i].life>0){
                    monsters[i].update(Shaun,map,monsters);}
                else
                    monsters[i]=null;
            }



    }

/** based on showMenu, the windowFrame1 or 2 is drawn on the screen */
    private void Draw() {
        int index;
        if(showMenu==true) {
            index=2;
        }
        else
        {
            index=1;
        }
        bs = wnd.GetCanvas(index).getBufferStrategy();
        wnd.GetJFRame(index).setVisible(true);
        /// Verific daca buffer strategy a fost construit sau nu
        if(bs == null)
        {
            /// Se executa doar la primul apel al metodei Draw()
            try
            {
                /// Se construieste tripul buffer
                wnd.GetCanvas(index).createBufferStrategy(3);
                return;
            }
            catch (IllegalArgumentException | IllegalStateException e)
            {
                /// Afisez informatii despre problema aparuta pentru depanare.
                e.printStackTrace();
            }
        }
        /// Se obtine contextul grafic curent in care se poate desena.
        g = bs.getDrawGraphics();
        /// Se sterge ce era
        g.clearRect(0, 0,Main.width, Main.height);
        wnd.GetCanvas(index).print(g);

        if(index==1) {
            if(Shaun.life<10 || (Shaun.worldX>=(map.nr_cols-3)*32 )) //condition for changing or reloading level
            {
                if (Shaun.life < 10) {
                    wnd.GetJFRame(index).setVisible(false);
                    InitGame(level+1);//reloading level

                    showMenu=false;
                }
                else //level passed
                {
                    if(level==3)
                    {
                        showMenu=true;
                        wnd.GetJFRame(index).setVisible(false);
                        InitGame(2);//reloads first level
                    }
                    else {
                        System.out.println(level);
                        wnd.GetJFRame(index).setVisible(false);
                        InitGame(level + 2);
                        showMenu = false;
                    }
                }
            }
            map.DrawMap(g, Shaun);
            Shaun.Draw(g);
            objectInventory.Draw(g, Shaun);
            for (int i = 0; i < objects.length; i++)
                if (objects[i] != null)
                    objects[i].Draw(g, Shaun);
            for (int i = 0; i < monsters.length; i++)
                if (monsters[i] != null)
                    monsters[i].draw(g, Shaun);
        }

        bs.show();

        /// Elibereaza resursele de memorie aferente contextului grafic curent (zonele de memorie ocupate de
        /// elementele grafice ce au fost desenate pe canvas).
        g.dispose();
        if(index==1)
        {
            if(keyHandler.esc==true)
            {
                try {
                    setDataBase();
                }
                catch (SQLException e)
                {
                    System.out.println("Eroare in KeyHandler.esc");
                }
                showMenu=true;
                wnd.GetJFRame(1).setVisible(false);
            }

        }
        else if(index==2)
        {
            if(wnd.getActionListener(1)!=null && wnd.getActionListener(1).isClicked==true)
            {
                //buton NewGame
                wnd.GetJFRame(2).setVisible(false);wnd.getActionListener(1).isClicked=false;

                InitGame(2);
                System.out.println("Level: "+ level);
                showMenu=false;
            }
            else if(wnd.getActionListener(2)!=null && wnd.getActionListener(2).isClicked==true){
                //buton LoadGame
                wnd.GetJFRame(2).setVisible(false);

                InitGame(1);
                wnd.getActionListener(2).isClicked=false;
                showMenu=false;
            }
        }
    }

    public void setDataBase() throws SQLException {
        PreparedStatement ps=c.prepareStatement("UPDATE Stats set LEVEL = ? where ID=1");
        ps.setInt(1,level);
        ps.executeUpdate();
        ps=c.prepareStatement("UPDATE Stats set LIFE = ? where ID=1");
        ps.setInt(1,(int)(Shaun.life));
        ps.executeUpdate();
        ps=c.prepareStatement("UPDATE Stats set Player_WorldX = ? where ID=1");
        ps.setInt(1,(int)(Shaun.worldX/32));
        ps.executeUpdate();
        ps=c.prepareStatement("UPDATE Stats set Player_WorldY = ? where ID=1");
        ps.setInt(1,Shaun.worldY/32);
        ps.executeUpdate();

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < objects.length; i++)
        {
            if(objects[i]!=null)
                sb.append(1);
            else
                sb.append(0);
            sb.append(",");

        }
        String objExistString = sb.toString();

        StringBuilder objT = new StringBuilder();
        for (int i = 0; i < objects.length; i++)
        {
            if(objects[i]!=null)
                sb.append(1);
            else
                sb.append(0);
            sb.append(",");

        }

        ps=c.prepareStatement("UPDATE Stats set OBJ_EXIST = ? where ID=1");
        ps.setString(1, objExistString);
        ps.executeUpdate();
        StringBuilder monsterLife = new StringBuilder();
        for(int i=0;i<15;i++)
        {
            if(monsters[i]!=null)
                monsterLife.append((int)(monsters[i].life));
            else
                monsterLife.append(0);
            monsterLife.append(",");
        }
        ps=c.prepareStatement("UPDATE Stats set MONSTER_LIFE = ? where ID=1");
        ps.setString(1, monsterLife.toString());
        ps.executeUpdate();

        StringBuilder objInventory = new StringBuilder();
        objInventory.append(objectInventory.nrPowerup1);
        objInventory.append(" ");
        objInventory.append(objectInventory.nrPowerup2);
        objInventory.append(" ");
        objInventory.append(objectInventory.nrCoins);
        objInventory.append(" ");
        ps=c.prepareStatement("UPDATE Stats set OBJ_INVENTORY = ? where ID=1");
        ps.setString(1,objInventory.toString());
        ps.executeUpdate();
        ResultSet rs;
        ps = c.prepareStatement("SELECT * FROM Stats WHERE ID=?;");
        ps.setInt(1, level + 1);
        rs = ps.executeQuery();
        if (rs.next()) {
            String obj_types = rs.getString("OBJ_TYPE");
            String monster_types = rs.getString("MONSTER_TYPE");
            ps = c.prepareStatement("UPDATE Stats set OBJ_TYPE = ? , MONSTER_TYPE = ? where ID=1");
            ps.setString(1, obj_types.toString());
            ps.setString(2, monster_types.toString());
            ps.executeUpdate();
        }

         
    }



}

