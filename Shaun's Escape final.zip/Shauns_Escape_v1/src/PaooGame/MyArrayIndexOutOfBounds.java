public class MatrixIndexOutOfBounds extends Exception {
    public int i;
    public int j;
    public MatrixIndexOutOfBounds(int i,int j){super();this.i=i;this.j=j;}

}
