package PaooGame.Graphics;
import java.awt.*;
import java.util.NoSuchElementException;
import java.util.Scanner;
import java.io.*;

import PaooGame.Entity.PlayerLevel1;
import PaooGame.Main;
import PaooGame.MatrixIndexOutOfBounds;
import PaooGame.MyInputMissMatchException;
import PaooGame.NegativeNumberException;
import PaooGame.Tiles.Tile;
import PaooGame.Tiles.TileFactory;

import static PaooGame.Tiles.Tile.*;
import static java.lang.System.exit;

public class Map
{
    public int level;
    public static int nr_cols;
    public static int nr_rows;
    public int[][] map_matrix;
    public int maxrows=Main.width/TILE_WIDTH;
    public int maxcols=Main.height/TILE_HEIGHT;
    TileFactory tileFactory;
    Tile tile;
    public Map(int level)
    {
        if(level==1)
        {nr_cols=127;nr_rows=20;}
        else if(level==2)
        {
            nr_cols=64;nr_rows=29;
        }
        else
        {
            nr_cols=128;nr_rows=22;
        }
        tileFactory = new TileFactory();
        map_matrix=new int[nr_rows][nr_cols];
        this.level=level;
        File file=null;
        try
        {
            if(level==1)
                file=new File("res/textures/maps/map_level1.txt") ;
            else if(level==2)
                file=new File("res/textures/maps/map_level2.txt") ;
            else
                file=new File("res/textures/maps/map_level3.txt") ;
            Scanner sc=new Scanner(file);
            for(int i=0;i<nr_rows;i++)
                for(int j=0;j<nr_cols;j++) {
                    map_matrix[i][j] = sc.nextInt();
                    if (map_matrix[i][j] > 23 && level == 3) {
                        map_matrix[i][j] = 14;
                    }
                }
        }
        catch(FileNotFoundException e)
        {
            System.out.println("File not found. Map is not valid");
            e.printStackTrace();
            exit(0);
        }
        catch(MyInputMissMatchException | NumberFormatException e)
        {
            e.getMessage();
            e.printStackTrace();
        }
        catch(NoSuchElementException e)
        {
            e.getMessage();
            e.printStackTrace();
        }

    }
    public void DrawMap(Graphics g, PlayerLevel1 Shaun) //draws the map on screen using the player's coordinates
    {
        int screenX;
        int screenY;


        int j_start=(Shaun.worldX-Shaun.screenX)/TILE_WIDTH;
        if(j_start<0)
            j_start=0;
        int j_finish=(Shaun.worldX+Shaun.screenX)/TILE_WIDTH+4;
        if(j_finish>nr_cols)
            j_finish=nr_cols;
        int i_start=(Shaun.worldY-Shaun.screenY)/TILE_WIDTH;
        if(i_start<0)
            i_start=0;
        int i_finish=(Shaun.worldY+Shaun.screenY)/TILE_WIDTH+2;
        if(i_finish>nr_rows)
            i_finish=nr_rows;
        for(int auxi=i_start;auxi<i_finish;auxi++)
            for(int auxj=j_start;auxj<j_finish;auxj++)
            {

                screenX=auxi*ACTUAL_TILE_HEIGHT-Shaun.worldY+Shaun.screenY;
                screenY=auxj*ACTUAL_TILE_WIDTH-Shaun.worldX+Shaun.screenX;
                tile = tileFactory.getTile(map_matrix[auxi][auxj]);
                if(map_matrix[auxi][auxj]!=-1) {
                    tile.Draw(g, screenY, screenX);
                }
            }
    }

    public int getTileID(int i,int j) throws MatrixIndexOutOfBounds //returns TileID from (i,j)position
    {
        if(j>nr_cols || i>nr_rows)
            throw new MatrixIndexOutOfBounds(i,j);
        return map_matrix[i][j];
    }
}
