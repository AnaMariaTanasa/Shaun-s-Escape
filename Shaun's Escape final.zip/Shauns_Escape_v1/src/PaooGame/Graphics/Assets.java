package PaooGame.Graphics;

import PaooGame.Entity.PlayerLevel1;

import java.awt.image.BufferedImage;
import java.io.IOException;

/*! \class public class Assets
    \brief Clasa incarca fiecare element grafic necesar jocului.

    Game assets include tot ce este folosit intr-un joc: imagini, sunete, harti etc.
 */
public class Assets
{
    /// Referinte catre elementele grafice (dale) utilizate in joc.
    public static BufferedImage mud;
    public static BufferedImage grass;
    public static BufferedImage mudCornerRight;
    public static BufferedImage mudCornerLeft;
    public static BufferedImage mudCorners;
    public static BufferedImage water;
    public static BufferedImage rock;

    public static BufferedImage[] textures;
    //Referinte catre png Shaun

    public static BufferedImage[] shaunWalkRight=new BufferedImage[4];
    public static BufferedImage[] shaunJumpRight=new BufferedImage[4];
    public static BufferedImage shaunIdle;
    public static BufferedImage shaunAttackRight;
    public static BufferedImage shaunAttackLeft;
    public static BufferedImage[] shaunWalkLeft=new BufferedImage[4];
    public static BufferedImage[] shaunJumpLeft=new BufferedImage[4];


    //Shirley

    public static BufferedImage[] shirleyWalkRight=new BufferedImage[4];
    public static BufferedImage[] shirleyJumpRight=new BufferedImage[4];
    public static BufferedImage shirleyIdleLeft;
    public static BufferedImage shirleyIdleRight;
    public static BufferedImage shirleyAttackRight;
    public static BufferedImage shirleyAttackLeft;
    public static BufferedImage[] shirleyWalkLeft=new BufferedImage[4];
    public static BufferedImage[] shirleyJumpLeft=new BufferedImage[4];

    //enemy
    public static BufferedImage[] farmerWalkLeft=new BufferedImage[2];
    public static BufferedImage[] farmerWalkRight=new BufferedImage[2];
    public static BufferedImage[] farmerAttackLeft=new BufferedImage[2];
    public static BufferedImage[] farmerAttackRight=new BufferedImage[2];
    public static BufferedImage farmerIdle;
    public static BufferedImage[] alienWalkLeft=new BufferedImage[2];
    public static BufferedImage[] alienWalkRight=new BufferedImage[2];
    public static BufferedImage[] alienAttackLeft=new BufferedImage[2];
    public static BufferedImage[] alienAttackRight=new BufferedImage[2];
    public static BufferedImage alienIdleRight,alienIdleLeft;
    public static BufferedImage[] bearWalkLeft=new BufferedImage[2];
    public static BufferedImage[] bearWalkRight=new BufferedImage[2];
    public static BufferedImage[] bearAttackLeft=new BufferedImage[2];
    public static BufferedImage[] bearAttackRight=new BufferedImage[2];
    public static BufferedImage[] bearJumpLeft=new BufferedImage[2];
    public static BufferedImage[] bearJumpRight=new BufferedImage[2];
    public static BufferedImage bearIdleRight,bearIdleLeft;
    public static BufferedImage[] wolfWalkLeft=new BufferedImage[2];
    public static BufferedImage[] wolfWalkRight=new BufferedImage[2];
    public static BufferedImage[] wolfAttackLeft=new BufferedImage[2];
    public static BufferedImage[] wolfAttackRight=new BufferedImage[2];
    public static BufferedImage wolfIdleRight,wolfIdleLeft;
    //objects
    public static BufferedImage coin;
    public static BufferedImage heart;
    public static BufferedImage halfHeart;
    public static BufferedImage healthPotion;
    public static BufferedImage sicknessPotion;
    public static BufferedImage powerup1;
    public static BufferedImage powerup2;
    public static BufferedImage shaunPictogram;
    /*! \fn public static void Init()
        \brief Functia initializaza referintele catre elementele grafice utilizate.

        Aceasta functie poate fi rescrisa astfel incat elementele grafice incarcate/utilizate
        sa fie parametrizate. Din acest motiv referintele nu sunt finale.
     */
    public static void Init()
    {
        /// Se creaza temporar un obiect SpriteSheet initializat prin intermediul clasei ImageLoader
        SpriteSheet sheet = new SpriteSheet(ImageLoader.LoadImage("/textures/tileset_level1.png"));
        SpriteSheet sheetL2=new SpriteSheet(ImageLoader.LoadImage("/textures/map2_tiles.png"));
        SpriteSheet sheetL3=new SpriteSheet(ImageLoader.LoadImage("/textures/tileset_level3.png"));
        textures = new BufferedImage[24];
        /// Se obtin subimaginile corespunzatoare elementelor necesare.
        textures[0]=mud = sheet.crop(0, 0);
        textures[1]=grass=sheet.crop(1,0);
        textures[4]=mudCornerLeft = sheet.crop(2, 0);
        textures[2]=mudCornerRight= sheet.crop(3, 0);
        textures[3]=mudCorners = sheet.crop(4, 0);
        textures[5]=water= sheet.crop(5, 0);
        textures[6]=rock= sheet.crop(6, 0);
        textures[7]=sheetL2.crop(0,0,88,90);
        textures[8]=sheetL2.crop(1,0,88,90);
        textures[9]=sheetL2.crop(2,0,88,90);
        textures[10]=sheetL2.crop(3,0,88,90);
        textures[11]=sheetL2.crop(4,0,88,90);
        textures[12]=sheetL2.crop(5,0,88,90);
        textures[13]=sheetL2.crop(6,0,86,90);
        textures[14]=sheetL3.crop(0,0,64,64);
        textures[15]=sheetL3.crop(1,0,64,64);
        textures[16]=sheetL3.crop(2,0,64,64);
        textures[17]=sheetL3.crop(3,0,64,64);
        textures[18]=sheetL3.crop(4,0,64,64);
        textures[19]=sheetL3.crop(5,0,64,64);
        textures[20]=sheetL3.crop(6,0,64,64);
        textures[21]=sheetL3.crop(7,0,64,64);
        textures[22]=sheetL3.crop(8,0,64,64);


        //objects
        try {
            SpriteSheet objectSpriteSheet = new SpriteSheet(ImageLoader.LoadImage("/textures/animated_items.png"));
            coin = objectSpriteSheet.crop(1, 0, 32, 32);
            heart = objectSpriteSheet.crop(1, 1, 32, 32);
            halfHeart = objectSpriteSheet.crop(2, 1, 16, 32);

            powerup1 = objectSpriteSheet.crop(1, 5, 32, 32);
            powerup2 = objectSpriteSheet.crop(1, 6, 32, 32);
            healthPotion = objectSpriteSheet.crop(1, 9, 32, 32);
            sicknessPotion = objectSpriteSheet.crop(1, 10, 32, 32);
        }
        catch(NullPointerException n)
        {
            System.out.println("Image in object Assets is null" );
            n.printStackTrace();
        }

        //enemy

        //farmer
        try {
            SpriteSheet farmerWalkLeftSheet = new SpriteSheet((ImageLoader.LoadImage("/textures/farmer_walk_left.png")));
            SpriteSheet farmerWalkRightSheet = new SpriteSheet((ImageLoader.LoadImage("/textures/farmer_walk_right.png")));
            SpriteSheet farmerAttackRightSheet = new SpriteSheet((ImageLoader.LoadImage("/textures/farmer_attack_right.png")));
            SpriteSheet farmerAttackLeftSheet = new SpriteSheet((ImageLoader.LoadImage("/textures/farmer_attack_left.png")));
            farmerWalkLeft[0] = farmerWalkLeftSheet.crop(0, 0, 200, 200);
            farmerWalkLeft[1] = farmerWalkLeftSheet.crop(1, 0, 200, 200);
            farmerWalkRight[0] = farmerWalkRightSheet.crop(0, 0, 200, 200);
            farmerWalkRight[1] = farmerWalkRightSheet.crop(0, 1, 200, 200);
            farmerAttackRight[0] = farmerAttackRightSheet.crop(0, 0, 250, 190);
            farmerAttackRight[1] = farmerAttackRightSheet.crop(0, 1, 250, 190);
            farmerAttackLeft[0] = farmerAttackLeftSheet.crop(0, 0, 250, 140);
            farmerAttackLeft[1] = farmerAttackLeftSheet.crop(0, 1, 250, 145);
            farmerIdle = farmerWalkRight[0];
        }
        catch(NullPointerException n)
        {
            System.out.println("Image in enemy-farmer Assets is null" );
            n.printStackTrace();
        }

        //alien
        try {
            SpriteSheet alienWalkSheet = new SpriteSheet((ImageLoader.LoadImage("/textures/alien_walk.png")));
            SpriteSheet alienAttackSheet = new SpriteSheet((ImageLoader.LoadImage("/textures/alien_attack.png")));
            SpriteSheet alienIdleSheet = new SpriteSheet((ImageLoader.LoadImage("/textures/alien_idle.png")));

            alienWalkRight[0] = alienWalkSheet.crop(0, 0, 200, 160);
            alienWalkRight[1] = alienWalkSheet.crop(0, 1, 200, 160);
            alienWalkLeft[0] = alienWalkSheet.crop(0, 2, 200, 160);
            alienWalkLeft[1] = alienWalkSheet.crop(0, 3, 200, 160);
            alienAttackRight[0] = alienAttackSheet.crop(0, 0, 200, 160);
            alienAttackRight[1] = alienAttackSheet.crop(0, 1, 200, 160);
            alienAttackLeft[0] = alienAttackSheet.crop(0, 2, 200, 160);
            alienAttackLeft[1] = alienAttackSheet.crop(0, 3, 200, 165);
            alienIdleRight = alienIdleSheet.crop(0, 0, 200, 160);
            alienIdleLeft = alienIdleSheet.crop(0, 1, 200, 165);
        }
        catch(NullPointerException n)
        {
            System.out.println("Image in enemy-alien Assets is null" );
            n.printStackTrace();
        }


        //bear
        try {
            SpriteSheet bearWalkSheet = new SpriteSheet((ImageLoader.LoadImage("/textures/bear_walk.png")));
            SpriteSheet bearAttackSheet = new SpriteSheet((ImageLoader.LoadImage("/textures/bear_attack.png")));
            SpriteSheet bearIdleSheet = new SpriteSheet((ImageLoader.LoadImage("/textures/bear_idle.png")));

            bearWalkLeft[0] = bearWalkSheet.crop(0, 0, 300, 160);
            bearWalkLeft[1] = bearWalkSheet.crop(0, 1, 300, 160);
            bearWalkRight[0] = bearWalkSheet.crop(0, 2, 300, 160);
            bearWalkRight[1] = bearWalkSheet.crop(0, 3, 300, 160);
            bearAttackRight[0] = bearAttackSheet.crop(0, 0, 300, 150);
            bearAttackRight[1] = bearAttackSheet.crop(0, 1, 300, 150);
            bearAttackLeft[0] = bearAttackSheet.crop(0, 2, 300, 160);
            bearAttackLeft[1] = bearAttackSheet.crop(0, 3, 300, 160);
            bearJumpRight[0] = bearWalkRight[1];
            bearJumpRight[1] = bearWalkRight[0];
            bearJumpLeft[0] = bearWalkLeft[1];
            bearJumpLeft[1] = bearWalkLeft[0];
            bearIdleRight = bearIdleSheet.crop(0, 0, 250, 150);
            bearIdleLeft = bearIdleSheet.crop(0, 1, 250, 150);
        }
        catch(NullPointerException n)
        {
            System.out.println("Image in enemy-bear Assets is null" );
            n.printStackTrace();
        }

        //wolf

        try {
            SpriteSheet wolfWalkSheet = new SpriteSheet((ImageLoader.LoadImage("/textures/wolf_walk.png")));
            SpriteSheet wolfAttackSheet = new SpriteSheet((ImageLoader.LoadImage("/textures/wolf_attack.png")));
            SpriteSheet wolfIdleSheet = new SpriteSheet((ImageLoader.LoadImage("/textures/wolf_idle.png")));

            wolfWalkRight[0] = wolfWalkSheet.crop(0, 0, 250, 120);
            wolfWalkRight[1] = wolfWalkSheet.crop(0, 1, 250, 130);
            wolfWalkLeft[0] = wolfWalkSheet.crop(0, 2, 250, 128);
            wolfWalkLeft[1] = wolfWalkSheet.crop(0, 3, 250, 130);
            wolfAttackRight[0] = wolfAttackSheet.crop(0, 0, 250, 120);
            wolfAttackRight[1] = wolfAttackSheet.crop(0, 1, 250, 130);
            wolfAttackLeft[0] = wolfAttackSheet.crop(0, 2, 250, 128);
            wolfAttackLeft[1] = wolfAttackSheet.crop(0, 3, 250, 130);
            wolfIdleRight = wolfIdleSheet.crop(0, 0, 330, 120);
            wolfIdleLeft = wolfIdleSheet.crop(0, 1, 330, 130);
        }
        catch(NullPointerException n)
        {
            System.out.println("Image in enemy-wolf Assets is null" );
            n.printStackTrace();
        }
        //shaun pictogram

        try {
            SpriteSheet shaun_pictogram = new SpriteSheet(ImageLoader.LoadImage("/textures/shaun-head.png"));
            shaunPictogram = shaun_pictogram.crop(0, 0, 76, 75);
        }
        catch(NullPointerException n)
        {
            System.out.println("Image in shaun-pictogram Assets is null" );
            n.printStackTrace();
        }
        //Shaun walk right
        try {
            SpriteSheet sheetShaunWalkRight = new SpriteSheet(ImageLoader.LoadImage("/textures/shaun_walk.png"));
            shaunWalkRight[0] = sheetShaunWalkRight.crop(0, 0, PlayerLevel1.PLAYER_WIDTH, PlayerLevel1.PLAYER_HEIGHT);
            shaunWalkRight[1] = sheetShaunWalkRight.crop(1, 0, PlayerLevel1.PLAYER_WIDTH, PlayerLevel1.PLAYER_HEIGHT);
            shaunWalkRight[2] = sheetShaunWalkRight.crop(2, 0, PlayerLevel1.PLAYER_WIDTH, PlayerLevel1.PLAYER_HEIGHT);
            shaunWalkRight[3] = sheetShaunWalkRight.crop(3, 0, PlayerLevel1.PLAYER_WIDTH, PlayerLevel1.PLAYER_HEIGHT);

            SpriteSheet sheetShaunWalkLeft = new SpriteSheet(ImageLoader.LoadImage("/textures/shaun_walk_left.png"));
            shaunWalkLeft[0] = sheetShaunWalkLeft.crop(0, 0, PlayerLevel1.PLAYER_WIDTH, PlayerLevel1.PLAYER_HEIGHT);
            shaunWalkLeft[1] = sheetShaunWalkLeft.crop(1, 0, PlayerLevel1.PLAYER_WIDTH, PlayerLevel1.PLAYER_HEIGHT);
            shaunWalkLeft[2] = sheetShaunWalkLeft.crop(2, 0, PlayerLevel1.PLAYER_WIDTH, PlayerLevel1.PLAYER_HEIGHT);
            shaunWalkLeft[3] = sheetShaunWalkLeft.crop(3, 0, PlayerLevel1.PLAYER_WIDTH, PlayerLevel1.PLAYER_HEIGHT);

            SpriteSheet sheetShaunJumpRight = new SpriteSheet(ImageLoader.LoadImage("/textures/shaun_jump.png"));
            shaunJumpRight[0] = sheetShaunJumpRight.crop(0, 0, PlayerLevel1.PLAYER_WIDTH, PlayerLevel1.PLAYER_HEIGHT);
            shaunJumpRight[1] = sheetShaunJumpRight.crop(1, 0, PlayerLevel1.PLAYER_WIDTH, PlayerLevel1.PLAYER_HEIGHT);
            shaunJumpRight[2] = sheetShaunJumpRight.crop(2, 0, PlayerLevel1.PLAYER_WIDTH, PlayerLevel1.PLAYER_HEIGHT);
            shaunJumpRight[3] = sheetShaunJumpRight.crop(3, 0, PlayerLevel1.PLAYER_WIDTH, PlayerLevel1.PLAYER_HEIGHT);

            shaunAttackRight = shaunJumpRight[3];

            SpriteSheet sheetShaunJumpLeft = new SpriteSheet(ImageLoader.LoadImage("/textures/shaun_jump_left.png"));
            shaunJumpLeft[0] = sheetShaunJumpLeft.crop(0, 0, PlayerLevel1.PLAYER_WIDTH, PlayerLevel1.PLAYER_HEIGHT);
            shaunJumpLeft[1] = sheetShaunJumpLeft.crop(1, 0, PlayerLevel1.PLAYER_WIDTH, PlayerLevel1.PLAYER_HEIGHT);
            shaunJumpLeft[2] = sheetShaunJumpLeft.crop(2, 0, PlayerLevel1.PLAYER_WIDTH, PlayerLevel1.PLAYER_HEIGHT);
            shaunJumpLeft[3] = sheetShaunJumpLeft.crop(3, 0, PlayerLevel1.PLAYER_WIDTH, PlayerLevel1.PLAYER_HEIGHT);
            shaunAttackLeft = shaunJumpLeft[3];
            SpriteSheet sheetShaunIdle = new SpriteSheet(ImageLoader.LoadImage("/textures/shaun_idle.png"));
            shaunIdle = sheetShaunIdle.crop(0, 0, PlayerLevel1.PLAYER_WIDTH, PlayerLevel1.PLAYER_HEIGHT);
        }
        catch(NullPointerException n)
        {
            System.out.println("Image in shaun Assets is null" );
            n.printStackTrace();
        }

        //shirley->Powerup1
        try {
            SpriteSheet shirleyWalkRightSheet = new SpriteSheet(ImageLoader.LoadImage("/textures/shirley_walk_right.png"));
            shirleyWalkRight[0] = shirleyWalkRightSheet.crop(0, 0, 300, 238);
            shirleyWalkRight[1] = shirleyWalkRightSheet.crop(0, 1, 300, 236);
            shirleyWalkRight[2] = shirleyWalkRightSheet.crop(0, 2, 300, 226);
            shirleyWalkRight[3] = shirleyWalkRightSheet.crop(0, 3, 300, 230);

            SpriteSheet shirleyWalkLeftSheet = new SpriteSheet(ImageLoader.LoadImage("/textures/shirley_walk_left.png"));
            shirleyWalkLeft[0] = shirleyWalkLeftSheet.crop(0, 0, 300, 150);
            shirleyWalkLeft[1] = shirleyWalkLeftSheet.crop(0, 1, 300, 165);
            shirleyWalkLeft[2] = shirleyWalkLeftSheet.crop(0, 2, 300, 170);
            shirleyWalkLeft[3] = shirleyWalkLeftSheet.crop(0, 3, 300, 170);

            SpriteSheet shirleyJumpLeftSheet = new SpriteSheet(ImageLoader.LoadImage("/textures/shirley_jump_left.png"));
            shirleyJumpLeft[0] = shirleyJumpLeftSheet.crop(0, 0, 300, 160);
            shirleyJumpLeft[1] = shirleyJumpLeftSheet.crop(0, 1, 300, 170);
            shirleyJumpLeft[2] = shirleyJumpLeftSheet.crop(0, 2, 300, 170);
            shirleyJumpLeft[3] = shirleyJumpLeftSheet.crop(0, 3, 300, 170);
            shirleyIdleLeft = shirleyJumpLeft[3];

            SpriteSheet shirleyJumpRightSheet = new SpriteSheet(ImageLoader.LoadImage("/textures/shirley_jump_right.png"));
            shirleyJumpRight[0] = shirleyJumpRightSheet.crop(0, 0, 300, 160);
            shirleyJumpRight[1] = shirleyJumpRightSheet.crop(0, 1, 300, 165);
            shirleyJumpRight[2] = shirleyJumpRightSheet.crop(0, 2, 300, 170);
            shirleyJumpRight[3] = shirleyJumpRightSheet.crop(0, 3, 300, 170);
            shirleyIdleRight = shirleyJumpRight[3];

            SpriteSheet shirleyAttackSheet = new SpriteSheet(ImageLoader.LoadImage("/textures/shirley_attack.png"));
            shirleyAttackRight = shirleyAttackSheet.crop(0, 0, 200, 160);
            shirleyAttackLeft = shirleyAttackSheet.crop(0, 1, 200, 160);
        }
        catch(NullPointerException n)
        {
            System.out.println("Image in shirley-Powerup1 Assets is null" );
            n.printStackTrace();
        }

    }
}
