package PaooGame.Graphics;

import java.awt.image.BufferedImage;

/*! \class public class SpriteSheet
    \brief Clasa retine o referinta catre o imagine formata din dale (sprite sheet)

    Metoda crop() returneaza o dala de dimensiuni fixe (o subimagine) din sprite sheet
    de la adresa (worldX * latimeDala, y * inaltimeDala)
 */
public class SpriteSheet
{
    private BufferedImage       spriteSheet;              /*!< Referinta catre obiectul BufferedImage ce contine sprite sheet-ul.*/
    private static final int    tileWidth   = 32;   /*!< Latimea unei dale din sprite sheet.*/
    private static final int    tileHeight  = 32;   /*!< Inaltime unei dale din sprite sheet.*/
    public int width;
    public int height;
    /*! \fn public SpriteSheet(BufferedImage sheet)
        \brief Constructor, initializeaza spriteSheet.

        \param img Un obiect BufferedImage valid.
     */
    public SpriteSheet(BufferedImage buffImg)
    {
        /// Retine referinta catre BufferedImage object.
        spriteSheet = buffImg;
        width=buffImg.getWidth();
        height=buffImg.getHeight();
    }

    /*! \fn public BufferedImage crop(int worldX, int y)
        \brief Returneaza un obiect BufferedImage ce contine o subimage (dala).

        Subimaginea este localizata avand ca referinta punctul din stanga sus.

        \param worldX numarul dalei din sprite sheet pe axa worldX.
        \param y numarul dalei din sprite sheet pe axa y.
     */


    /*! \fn public BufferedImage crop(int worldX, int y)
            \brief Returneaza un obiect BufferedImage ce contine o subimage (dala).

            Subimaginea este localizata avand ca referinta punctul din stanga sus.

            \param worldX numarul dalei din sprite sheet pe axa worldX.
            \param y numarul dalei din sprite sheet pe axa y.
         */
    public BufferedImage crop(int x,int y,int tileWidth, int tileHeight)
    {
        /// Subimaginea (dala) este regasita in sprite sheet specificad coltul stanga sus
        /// al imaginii si apoi latimea si inaltimea (totul in pixeli). Coltul din stanga sus al imaginii
        /// se obtine inmultind numarul de ordine al dalei cu dimensiunea in pixeli a unei dale.
        return spriteSheet.getSubimage(x * tileWidth, y * tileHeight, tileWidth, tileHeight);
    }

    public BufferedImage crop(int x,int y)
    {
        return crop(x,y,32,32);

    }

}
