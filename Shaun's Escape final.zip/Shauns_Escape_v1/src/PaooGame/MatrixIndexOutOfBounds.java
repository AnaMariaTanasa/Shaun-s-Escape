package PaooGame;

//custom exception class
public class MatrixIndexOutOfBounds extends Exception{
    public int i,j;
    public MatrixIndexOutOfBounds(int i,int j){super();this.i=i;this.j=j;}
    @Override
    public String getMessage(){
        return "Matrix index out of bounds i = "+i+", j = "+j;
    }
}