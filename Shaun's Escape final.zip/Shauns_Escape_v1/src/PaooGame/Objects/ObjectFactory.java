package PaooGame.Objects;

import java.awt.image.BufferedImage;

public class ObjectFactory implements ObjectFactoryInterface{
    @Override
    /** returns an Object based on its type */
    public  AbstractObject getObj(String type)
    {
        AbstractObject obj=null;
        switch(type)
        {
            case "Coin":
                obj= new Coin();
                break;
            case "HealthPotion":
                obj= new HealthPotion();
                break;
            case "SicknessPotion":
                obj= new SicknessPotion();
                break;
            case "Powerup1":
               obj= new PowerUp1();
               break;
            case "Powerup2":
                obj= new PowerUp2();
        }
        return obj;
    }
}
