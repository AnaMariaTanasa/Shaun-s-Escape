package PaooGame.Objects;

import PaooGame.Entity.PlayerLevel1;

import java.awt.*;

import static PaooGame.Graphics.Assets.coin;
import static PaooGame.Graphics.Assets.powerup1;
import static PaooGame.Tiles.Tile.ACTUAL_TILE_HEIGHT;
import static PaooGame.Tiles.Tile.ACTUAL_TILE_WIDTH;

public class PowerUp1 extends AbstractObject {


    @Override
    public void addToInventory(ObjectInventory inventory) {
        inventory.nrPowerup1++;
    }


    @Override
    public void Draw(Graphics g,PlayerLevel1 player) {

        int screenX=worldX- player.worldX+ player.screenX;
        int screenY=worldY- player.worldY+ player.screenY;
        if(worldX+ACTUAL_TILE_WIDTH> player.worldX- player.screenX &&
                worldX-ACTUAL_TILE_WIDTH< player.worldX+ player.screenX &&
                worldY+ACTUAL_TILE_HEIGHT> player.worldY- player.screenY &&
                worldY-ACTUAL_TILE_HEIGHT< player.worldY+ player.screenY)
            g.drawImage(powerup1,screenX,screenY,objWidth,objHeight,null);
    }

    public PowerUp1()
    {
        super(0,0);
    }


}
