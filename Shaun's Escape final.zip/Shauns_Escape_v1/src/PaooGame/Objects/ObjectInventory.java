package PaooGame.Objects;

import PaooGame.Entity.PlayerLevel1;
import PaooGame.Main;
import PaooGame.NegativeNumberException;

import java.awt.*;

import static PaooGame.Graphics.Assets.*;

public class ObjectInventory {

    public int nrPowerup1;
    public int nrPowerup2;
    public int nrCoins;

    public ObjectInventory(int nrp1,int nrp2,int nrc)
    {
        nrPowerup1 = nrp1;
        nrPowerup2 = nrp2;
        nrCoins = nrc;
    }

    public void  Draw(Graphics g, PlayerLevel1 Shaun)
    {
        g.drawImage(shaunPictogram,0,0,64,64,null);
        int nrHearts=(int)Shaun.life/10;
        for(int i=0;i<nrHearts;i++)
            g.drawImage(heart,(i+2)*32,0,32,32,null);
        if(nrHearts*10<Shaun.life)
            g.drawImage(halfHeart,(nrHearts+2)*32,0,16,32,null);
        g.setColor(Color.BLUE);
        Font font=new Font("Arial",Font.BOLD,20);
        g.setFont(font);
        try {
            g.drawString(String.valueOf(nrCoins), 670, 25);
            if(nrCoins<0)
                throw new NegativeNumberException("Object Inventory coins is negative");
            g.drawImage(coin, 680, 0, 32, 32, null);
            g.drawString(String.valueOf(nrPowerup1), 720, 25);
            if(nrPowerup1<0)
                throw new NegativeNumberException("Object Inventory coins is negative");
            g.drawImage(powerup1, 730, 0, 32, 32, null);
            if(nrPowerup2<0)
                throw new NegativeNumberException("Object Inventory coins is negative");
            g.drawString(String.valueOf(nrPowerup2), 760, 25);
            g.drawImage(powerup2, 770, 0, 36, 36, null);
        }
        catch(NegativeNumberException e)
        {
            e.getMessage();
        }

    }
}
