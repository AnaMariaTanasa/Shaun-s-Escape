package PaooGame.Objects;
import java.util.Scanner;

import static PaooGame.Tiles.Tile.*;
public class ObjectSetter {

    public static void setObjects(int level,AbstractObject[] objects,String objExist,String objType)
    {
        ObjectFactory factory=new ObjectFactory();
        String[] objectExists=objExist.split(",");
        String[] objectTypes=objType.split(" ");
        try {
            for (int i = 0; i < objectExists.length; i++) {
                if (objectExists[i].equals("1"))
                    objects[i] = factory.getObj(objectTypes[i]);

            }
        }
        catch(ArrayIndexOutOfBoundsException a)
            {

                a.printStackTrace();
            }

        if(level==1)
        {
            if(objects[0]!=null) {
                objects[0].setWorldX(11 * ACTUAL_TILE_WIDTH);
                objects[0].setWorldY(9 * ACTUAL_TILE_HEIGHT);
            }
            if(objects[1]!=null)
            {
                objects[1].setWorldX(25 * ACTUAL_TILE_WIDTH);
                objects[1].setWorldY(12 * ACTUAL_TILE_HEIGHT);
            }
            if(objects[2]!=null) {
                objects[2].setWorldX(40 * ACTUAL_TILE_WIDTH);
                objects[2].setWorldY(7 * ACTUAL_TILE_HEIGHT);
            }
            if(objects[3]!=null) {
                objects[3].setWorldX(50*ACTUAL_TILE_WIDTH);
                objects[3].setWorldY(13*ACTUAL_TILE_HEIGHT);
            }
            if(objects[4]!=null) {
                objects[4].setWorldX(59*ACTUAL_TILE_WIDTH);
                objects[4].setWorldY(8*ACTUAL_TILE_HEIGHT);
            }
            if(objects[5]!=null) {
                objects[5].setWorldX(110*ACTUAL_TILE_WIDTH);
                objects[5].setWorldY(7*ACTUAL_TILE_HEIGHT);
            }
        }else if(level==2)
        {
           if(objects[0]!=null) {
               objects[0].setWorldX(13 * ACTUAL_TILE_WIDTH);
               objects[0].setWorldY(5 * ACTUAL_TILE_HEIGHT);
           }
           if(objects[1]!=null)
           {
               objects[1].setWorldX(26 * ACTUAL_TILE_WIDTH);
               objects[1].setWorldY(6 * ACTUAL_TILE_HEIGHT);
           }
           if(objects[2]!=null) {
               objects[2].setWorldX(43 * ACTUAL_TILE_WIDTH);
               objects[2].setWorldY(8 * ACTUAL_TILE_HEIGHT);
           }
           if(objects[3]!=null) {
               objects[3].setWorldX(61*ACTUAL_TILE_WIDTH);
               objects[3].setWorldY(10*ACTUAL_TILE_HEIGHT);
           }
           if(objects[4]!=null) {
               objects[4].setWorldX(4*ACTUAL_TILE_WIDTH);
               objects[4].setWorldY(20*ACTUAL_TILE_HEIGHT);
           }
           if(objects[5]!=null) {
               objects[5].setWorldX(15*ACTUAL_TILE_WIDTH);
               objects[5].setWorldY(19*ACTUAL_TILE_HEIGHT);
           }
           if(objects[6]!=null) {
               objects[6].setWorldX(26*ACTUAL_TILE_WIDTH);
               objects[6].setWorldY(23*ACTUAL_TILE_HEIGHT);
           }
           if(objects[7]!=null) {
               objects[7].setWorldX(42*ACTUAL_TILE_WIDTH);
               objects[7].setWorldY(18*ACTUAL_TILE_HEIGHT);
           }
           if(objects[8]!=null) {
               objects[8].setWorldX(57*ACTUAL_TILE_WIDTH);
               objects[8].setWorldY(16*ACTUAL_TILE_HEIGHT);
           }


        }
        else if(level==3)
        {
            if(objects[0]!=null) {
                objects[0].setWorldX(7 * ACTUAL_TILE_WIDTH);
                objects[0].setWorldY(15 * ACTUAL_TILE_HEIGHT);
            }
            if(objects[1]!=null)
            {
                objects[1].setWorldX(18 * ACTUAL_TILE_WIDTH);
                objects[1].setWorldY(8 * ACTUAL_TILE_HEIGHT);
            }
            if(objects[2]!=null) {
                objects[2].setWorldX(33 * ACTUAL_TILE_WIDTH);
                objects[2].setWorldY(15 * ACTUAL_TILE_HEIGHT);
            }
            if(objects[3]!=null) {
                objects[3].setWorldX(43*ACTUAL_TILE_WIDTH);
                objects[3].setWorldY(15*ACTUAL_TILE_HEIGHT);
            }
            if(objects[4]!=null) {
                objects[4].setWorldX(54*ACTUAL_TILE_WIDTH);
                objects[4].setWorldY(9*ACTUAL_TILE_HEIGHT);
            }
            if(objects[5]!=null) {
                objects[5].setWorldX(69*ACTUAL_TILE_WIDTH);
                objects[5].setWorldY(15*ACTUAL_TILE_HEIGHT);
            }
            if(objects[6]!=null) {
                objects[6].setWorldX(83*ACTUAL_TILE_WIDTH);
                objects[6].setWorldY(11*ACTUAL_TILE_HEIGHT);
            }
            if(objects[7]!=null) {
                objects[7].setWorldX(99*ACTUAL_TILE_WIDTH);
                objects[7].setWorldY(14*ACTUAL_TILE_HEIGHT);
            }
            if(objects[8]!=null) {
                objects[8].setWorldX(112*ACTUAL_TILE_WIDTH);
                objects[8].setWorldY(17*ACTUAL_TILE_HEIGHT);
            }
            if(objects[9]!=null) {
                objects[9].setWorldX(115*ACTUAL_TILE_WIDTH);
                objects[9].setWorldY(4*ACTUAL_TILE_HEIGHT);
            }
            if(objects[10]!=null) {
                objects[10].setWorldX(118*ACTUAL_TILE_WIDTH);
                objects[10].setWorldY(12*ACTUAL_TILE_HEIGHT);
            }
            if(objects[11]!=null) {
                objects[11].setWorldX(123*ACTUAL_TILE_WIDTH);
                objects[11].setWorldY(12*ACTUAL_TILE_HEIGHT);
            }
            if(objects[12]!=null) {
                objects[12].setWorldX(110*ACTUAL_TILE_WIDTH);
                objects[12].setWorldY(14*ACTUAL_TILE_HEIGHT);
            }
            if(objects[13]!=null) {
                objects[13].setWorldX(83*ACTUAL_TILE_WIDTH);
                objects[13].setWorldY(5*ACTUAL_TILE_HEIGHT);
            }

        }
    }
}
