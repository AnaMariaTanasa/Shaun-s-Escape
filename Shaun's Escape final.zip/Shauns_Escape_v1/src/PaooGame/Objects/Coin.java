package PaooGame.Objects;

import PaooGame.Entity.PlayerLevel1;

import java.awt.*;
import static PaooGame.Graphics.Assets.coin;
import static PaooGame.Tiles.Tile.*;
public class Coin extends AbstractObject{

    @Override
    public void addToInventory(ObjectInventory inventory) {
        inventory.nrCoins++;
    }

    public Coin()
    {
        super(0,0);
    }
    public Coin(int x, int y)
    {
        super(x,y);
    }
    @Override
    /** Draws objects on screen based on graphics and player */
    public void Draw(Graphics g,PlayerLevel1 player) {

        //determines the object's position on screen
        int screenX=worldX- player.worldX+ player.screenX;
        int screenY=worldY- player.worldY+ player.screenY;
        //if it is visible, then draw
        if(worldX+ACTUAL_TILE_WIDTH> player.worldX- player.screenX &&
        worldX-ACTUAL_TILE_WIDTH< player.worldX+ player.screenX &&
        worldY+ACTUAL_TILE_HEIGHT> player.worldY- player.screenY &&
        worldY-ACTUAL_TILE_HEIGHT< player.worldY+ player.screenY)
        g.drawImage(coin,screenX,screenY,objWidth,objHeight,null);
    }
}
