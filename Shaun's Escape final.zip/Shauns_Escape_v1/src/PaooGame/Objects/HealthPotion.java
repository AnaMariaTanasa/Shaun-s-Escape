package PaooGame.Objects;

import PaooGame.Entity.PlayerLevel1;

import java.awt.*;

import static PaooGame.Graphics.Assets.coin;
import static PaooGame.Graphics.Assets.healthPotion;
import static PaooGame.Tiles.Tile.ACTUAL_TILE_HEIGHT;
import static PaooGame.Tiles.Tile.ACTUAL_TILE_WIDTH;

public class HealthPotion extends AbstractObject
{
    @Override
    public void effectOnPlayer(PlayerLevel1 player) {
        player.life+=5;
    }


    public HealthPotion()
    {
        super(0,0);
    }

   @Override
    public void Draw(Graphics g,PlayerLevel1 player) {

        int screenX=worldX- player.worldX+ player.screenX;
        int screenY=worldY- player.worldY+ player.screenY;
        if(worldX+ACTUAL_TILE_WIDTH> player.worldX- player.screenX &&
                worldX-ACTUAL_TILE_WIDTH< player.worldX+ player.screenX &&
                worldY+ACTUAL_TILE_HEIGHT> player.worldY- player.screenY &&
                worldY-ACTUAL_TILE_HEIGHT< player.worldY+ player.screenY)
            g.drawImage(healthPotion,screenX,screenY,objWidth,objHeight,null);
    }
}
