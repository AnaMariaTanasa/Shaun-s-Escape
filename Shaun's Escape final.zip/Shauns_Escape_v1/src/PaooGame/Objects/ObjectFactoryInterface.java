package PaooGame.Objects;

public interface ObjectFactoryInterface {
    public  AbstractObject getObj(String type);

}
