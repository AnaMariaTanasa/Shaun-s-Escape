package PaooGame.Objects;

import PaooGame.Entity.PlayerLevel1;

import java.awt.*;

public interface ObjectInterface {
    public static int objHeight=32;
    public static int objWidth=32;
    public void effectOnPlayer(PlayerLevel1 player);
    public void addToInventory(ObjectInventory inventory);
    public void Draw(Graphics g,PlayerLevel1 player);
}
