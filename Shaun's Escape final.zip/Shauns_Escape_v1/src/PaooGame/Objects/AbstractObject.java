package PaooGame.Objects;

import PaooGame.Entity.PlayerLevel1;

import java.awt.*;

import static PaooGame.Graphics.Assets.coin;
import static PaooGame.Tiles.Tile.ACTUAL_TILE_HEIGHT;
import static PaooGame.Tiles.Tile.ACTUAL_TILE_WIDTH;

/** abstract class extended by all objects ;used for implmeneting an object factory */
public class AbstractObject implements ObjectInterface{
    protected int worldX;
    protected int worldY;
    public Rectangle solidArea ;//used for implementing collisions
    public int solidAreaDefaultX;
    public int solidAreaDefaultY;
    public AbstractObject(int x,int y) {
        worldX = x;
        worldY = y;
        solidAreaDefaultX=0;
        solidAreaDefaultY=0;
        solidArea=new Rectangle(0,0,objWidth,objHeight);
    }
    public AbstractObject() {
        this(0,0);
    }
    public int getWorldX() {
        return worldX;
    }
    public int getWorldY() {
        return worldY;
    }
    public void setWorldX(int x) {worldX = x;}
    public void setWorldY(int y) {worldY = y;}

    @Override

    /** adds object to an inventory */
    public void addToInventory(ObjectInventory inventory) {

    }

    @Override
    public void effectOnPlayer(PlayerLevel1 player) {

    }

    @Override
    public void Draw(Graphics g,PlayerLevel1 player) {

    }

}
