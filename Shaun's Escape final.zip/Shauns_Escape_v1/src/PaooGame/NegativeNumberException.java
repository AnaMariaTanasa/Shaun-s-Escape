package PaooGame;

public class NegativeNumberException extends Exception{
    public String location;
    public NegativeNumberException(String location){
        super();
        this.location=location;
    }
    @Override
    public String getMessage()
    {
        return "Negative Number Exception at "+location;
    }
}
